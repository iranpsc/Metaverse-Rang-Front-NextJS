
export const rewards = {
    items: [
        {
            title: 'دریافت PSC',
            value: '0',
            colNumber: 1
        },
        {
            title: 'دریافت رنگ آبی',
            value: '0',
            colNumber: 1
        },
        {
            title: 'دریافت رنگ زرد',
            value: 50,
            colNumber: 1
        },

        {
            title: 'دریافت رنگ قرمز',
            value: 50,
            colNumber: 2
        },

        {
            title: 'واحد رضایت',
            value: '0.03',
            colNumber: 2
        },

      
    ]
}