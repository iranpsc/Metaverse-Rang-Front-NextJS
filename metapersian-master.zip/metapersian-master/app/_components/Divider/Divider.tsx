import React from 'react'

export const Divider = () => {
    return (
        <div className='w-full bg-dark-on-bg h-1'></div>
    )
}
