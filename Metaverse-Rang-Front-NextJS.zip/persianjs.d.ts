declare module 'persianjs';
