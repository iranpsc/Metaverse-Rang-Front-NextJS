// app/[lang]/news/page.tsx

import BreadCrumb from "@/components/shared/BreadCrumb";
import LatestNews from "../../../components/features/LatestNews";
import PopularNews from "../../../components/features/PopularNews";
import SearchComponent from "@/components/Search/SearchComponent";
import BreakingNewsSlider from "../../../components/features/BreakingNewsSlider/BreakingNewsSlider.server";
import CustomErrorPage from "@/components/error/CustomErrorPage";
import NewsCategoriesSection from "../../../components/features/NewsCategoriesSection";
import VideoNewsList from "../../../components/features/VideoNewsList";
import { supabase } from "@/utils/lib/supabaseClient";
import { getTranslation, getMainFile } from "@/components/utils/actions";
import { findByUniqueId } from "@/components/utils/findByUniqueId";

// ایمپورت دیتای استاتیک به عنوان fallback
import fallbackNewsData from "@/components/utils/news.json";
import Link from "next/link";

// ─── Types (اگر در فایل جداگانه نیست، اینجا تعریف کن) ───
type NewsItem = {
  id: number;
  title: string;
  slug: string;
  image?: string | null;
  date?: string | null;
  readingTime?: string | null;
  stats?: any;
  category?: string | null;
  categorySlug?: string | null;
};

type Category = {
  title: string;
  slug: string;
};

interface NewsPageProps {
  params: Promise<{ lang: string }>;
}

const baseUrl = "https://metarang.com";
const imageUrl = "https://metarang.com/_next/image?url=%2Flogo.png&w=128&q=75";

// ─── تابع کمکی برای نرمالایز کردن دیتای دریافتی ───
function normalizeNewsItem(item: any): NewsItem {
  return {
    id: item.id,
    title: item.title,
    slug: item.slug,
    image: item.image || null,
    date: item.date || null,
    readingTime: item.readingTime || null,
    stats: item.stats || null,
    category: item.category || null,
    categorySlug: item.categorySlug || null,
  };
}

// ─── تابع دریافت دیتا با fallback به news.json ───
async function fetchNewsWithFallback() {
  try {
    // تلاش برای دریافت از Supabase
    const { data: supabaseNews, error } = await supabase
      .from("news")
      .select("id, title, slug, image, date, readingTime, stats, category, categorySlug")
      .order("date", { ascending: false })
      .limit(40);

    // اگر خطایی رخ داد یا دیتایی نیامد، از fallback استفاده کن
    if (error || !supabaseNews || supabaseNews.length === 0) {
      if (error) {
        console.warn("⚠️ Supabase error, using fallback news.json:", error.message);
      } else if (!supabaseNews || supabaseNews.length === 0) {
        console.warn("⚠️ No data from Supabase, using fallback news.json");
      }

      // تبدیل دیتای news.json به فرمت مناسب با نرمالایز کردن
      const fallbackData = fallbackNewsData.map((item: any) => normalizeNewsItem({
        id: item.id,
        title: item.title,
        slug: item.slug,
        image: item.image,
        date: item.date,
        readingTime: item.readingTime,
        stats: item.stats,
        category: item.category,
        categorySlug: item.categorySlug,
      }));

      return { data: fallbackData, fromFallback: true };
    }

    // نرمالایز کردن دیتای دریافتی از Supabase
    const normalizedData = supabaseNews.map((item: any) => normalizeNewsItem(item));

    return { data: normalizedData, fromFallback: false };
  } catch (err) {
    // در صورت بروز هرگونه خطای غیرمنتظره، از fallback استفاده کن
    console.error("❌ Unexpected error fetching news, using fallback:", err);
    const fallbackData = fallbackNewsData.map((item: any) => normalizeNewsItem({
      id: item.id,
      title: item.title,
      slug: item.slug,
      image: item.image,
      date: item.date,
      readingTime: item.readingTime,
      stats: item.stats,
      category: item.category,
      categorySlug: item.categorySlug,
    }));

    return { data: fallbackData, fromFallback: true };
  }
}

// Metadata ...
export async function generateMetadata({ params }: NewsPageProps) {
  const resolvedParams = await params;
  const { lang } = resolvedParams;
  try {
    const url = `${baseUrl}/${lang}/news`;

    return {
      title: lang === "fa" ? "اخبار متاورس رنگ | متارنگ" : "Metarangs Metaverse News | Matarang",
      description:
        lang === "fa"
          ? "آخرین اخبار و بروزرسانی‌های متاورس رنگ را در این صفحه دنبال کنید."
          : "Follow the latest news and updates of Metarang — Iran's first national metaverse.",
      openGraph: {
        title:
          lang === "fa"
            ? "اخبار متاورس رنگ"
            : "Metarangs Metaverse News",
        description:
          lang === "fa"
            ? "آخرین اخبار و بروزرسانی‌های متاورس رنگ را در این صفحه دنبال کنید."
            : "Follow the latest news and updates of Metarang — Iran's first national metaverse.",
        url,
        siteName: "Metaverse Rang",
        locale: lang === "fa" ? "fa_IR" : "en_US",
        type: "website",
        images: [
          {
            url: imageUrl,
            width: 800,
            height: 600,
            alt: "اخبار متاورس رنگ",
          },
        ],
      },
      twitter: {
        card: "summary_large_image",
        title:
          lang === "fa"
            ? "اخبار متاورس رنگ"
            : "Metarangs Metaverse News",
        description:
          lang === "fa"
            ? "آخرین اخبار متاورس رنگ"
            : "Latest Metarangs Metaverse News",
        images: [imageUrl],
      },
    };
  } catch (error) {
    console.error("❌ Metadata error (NewsPage):", error);
    return {
      title: "خطا",
      description: "مشکلی در بارگذاری صفحه رخ داده است",
    };
  }
}

export default async function NewsPage({ params }: NewsPageProps) {
  const resolvedParams = await params;
  const { lang } = resolvedParams;
  try {
    const langData = await getTranslation(lang);
    const mainData = await getMainFile(langData);
    const newsUrl = `${baseUrl}/${lang}/news`;

    // ─── دریافت اخبار با قابلیت fallback ───
    const { data: allNews, fromFallback } = await fetchNewsWithFallback();

    // اگر در حین دریافت fallback هم دیتایی نیامد (فایل JSON خالی یا نامعتبر)
    if (!allNews || allNews.length === 0) {
      console.error("❌ No news data available from both Supabase and fallback");
      // می‌توانید یک آرایه خالی برگردانید یا صفحه خطای سفارشی نشان دهید
      // const emptyNews: NewsItem[] = [];

      const jsonLd = {
        "@context": "https://schema.org",
        "@graph": [
          {
            "@type": "BreadcrumbList",
            "itemListElement": [
              { "@type": "ListItem", "position": 1, "name": "صفحه اصلی", "item": `${baseUrl}/${lang}` },
              { "@type": "ListItem", "position": 2, "name": "اخبار", "item": newsUrl },
            ],
          },
          {
            "@type": "Organization",
            "@id": `${baseUrl}#organization`,
            "name": "MetaRang",
            "url": baseUrl,
            "logo": { "@type": "ImageObject", "url": imageUrl },
          },
          {
            "@type": "WebSite",
            "@id": `${baseUrl}#website`,
            "url": baseUrl,
            "name": "MetaRang",
            "publisher": { "@id": `${baseUrl}#organization` },
            "inLanguage": lang === "fa" ? "fa-IR" : "en-US",
          },
          {
            "@type": "CollectionPage",
            "@id": `${newsUrl}#webpage`,
            "url": newsUrl,
            "name": lang === "fa" ? "اخبار متاورس رنگ" : "Metarang News",
            "description": lang === "fa" ? "آخرین اخبار و رویدادهای متاورس رنگ" : "Latest news and updates from Metarang Metaverse",
            "isPartOf": { "@id": `${baseUrl}#website` },
            "about": { "@type": "Thing", "name": "News" },
            "inLanguage": lang === "fa" ? "fa-IR" : "en-US",
          },
        ],
      };

      return (
        <section className="w-full relative lg:pt-0 bg-bg-primary " dir={langData.direction}>
          <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />zz
          <div className="px-5 2xl:px-10 mt-[60px] lg:mt-0">
            <BreadCrumb params={params} />
          </div>
          <div className="text-center py-20">
            <p className="text-xl dark:text-white">هیچ خبری یافت نشد</p>
          </div>
        </section>
      );
    }

    // ─── ساخت دسته‌های یکتا ───
    const uniqueMap = new Map<string, Category>();

    allNews.forEach((news: NewsItem) => {
      if (news.category && news.categorySlug) {
        if (!uniqueMap.has(news.categorySlug)) {
          uniqueMap.set(news.categorySlug, {
            title: news.category,
            slug: news.categorySlug,
          });
        }
      }
    });

    const categories: Category[] = [
      { title: "همه حوزه‌های خبری", slug: "all" },
      ...Array.from(uniqueMap.values()),
    ];

    // ─── گروه‌بندی اخبار بر اساس categorySlug ───
    const newsByCategory: Record<string, NewsItem[]> = { all: allNews };

    allNews.forEach((news) => {
      if (news.categorySlug) {
        if (!newsByCategory[news.categorySlug]) {
          newsByCategory[news.categorySlug] = [];
        }
        newsByCategory[news.categorySlug].push(news);
      }
    });

    const jsonLd = {
      "@context": "https://schema.org",
      "@graph": [
        /* ================= Breadcrumb ================= */
        {
          "@type": "BreadcrumbList",
          "itemListElement": [
            {
              "@type": "ListItem",
              "position": 1,
              "name": "صفحه اصلی",
              "item": `${baseUrl}/${lang}`,
            },
            {
              "@type": "ListItem",
              "position": 2,
              "name": "اخبار",
              "item": newsUrl,
            },
          ],
        },

        /* ================= Organization ================= */
        {
          "@type": "Organization",
          "@id": `${baseUrl}#organization`,
          "name": "MetaRang",
          "url": baseUrl,
          "logo": {
            "@type": "ImageObject",
            "url": imageUrl,
          },
        },

        /* ================= WebSite ================= */
        {
          "@type": "WebSite",
          "@id": `${baseUrl}#website`,
          "url": baseUrl,
          "name": "MetaRang",
          "publisher": {
            "@id": `${baseUrl}#organization`,
          },
          "inLanguage": lang === "fa" ? "fa-IR" : "en-US",
        },

        /* ================= Collection Page ================= */
        {
          "@type": "CollectionPage",
          "@id": `${newsUrl}#webpage`,
          "url": newsUrl,
          "name":
            lang === "fa"
              ? "اخبار متاورس رنگ"
              : "Metarang News",
          "description":
            lang === "fa"
              ? "آخرین اخبار و رویدادهای متاورس رنگ"
              : "Latest news and updates from Metarang Metaverse",
          "isPartOf": {
            "@id": `${baseUrl}#website`,
          },
          "about": {
            "@type": "Thing",
            "name": "News",
          },
          "inLanguage": lang === "fa" ? "fa-IR" : "en-US",
        },
      ],
    };

    // در صورت استفاده از fallback، می‌توانید یک warning در کنسول نشان دهید (اختیاری)
    if (fromFallback) {
      console.log("ℹ️ News data is currently being served from fallback JSON file");
    }

    return (
      <section
        className="w-full relative lg:pt-0 bg-bg-primary "
        dir={langData.direction}
      >
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />
        <div className="fixed z-1000 inset-e-10 bottom-[100px]">
          <Link aria-label="SocialLink" href={"#em"} className="bg-primary  rounded-full w-[60px] h-[60px]  flex items-center justify-center">

            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path className="stroke-white dark:stroke-black  stroke-2" d="M22 11.5V15.5C22 19 20 20.5 17 20.5H7C4 20.5 2 19 2 15.5V8.5C2 5 4 3.5 7 3.5H12" stroke-width="2" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round" />
              <path className="stroke-white dark:stroke-black stroke-2" d="M7 9L11 11.5C12.048 12.2897 13.952 11.2897 15 10.5" stroke-width="2" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round" />
              <path d="M19.0062 1.96875C17.9029 1.96875 17.0062 2.86542 17.0062 3.96875V4.93208C17.0062 5.13542 16.9195 5.44542 16.8162 5.61875L16.4329 6.25542C16.1962 6.64875 16.3595 7.08542 16.7929 7.23208C18.2295 7.71208 19.7795 7.71208 21.2162 7.23208C21.6195 7.09875 21.7962 6.62208 21.5762 6.25542L21.1929 5.61875C21.0929 5.44542 21.0062 5.13542 21.0062 4.93208V3.96875C21.0062 2.86875 20.1062 1.96875 19.0062 1.96875Z" stroke="#18C08F" stroke-miterlimit="10" stroke-linecap="round" />
              <path className="stroke-white dark:stroke-black" d="M19.623 2.06844C19.5196 2.03844 19.413 2.0151 19.303 2.00177C18.983 1.96177 18.6763 1.9851 18.3896 2.06844C18.4863 1.82177 18.7263 1.64844 19.0063 1.64844C19.2863 1.64844 19.5263 1.82177 19.623 2.06844Z" stroke-width="2" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round" />
              <path className="stroke-white dark:stroke-black" d="M20.0068 7.35156C20.0068 7.90156 19.5568 8.35156 19.0068 8.35156C18.7335 8.35156 18.4802 8.23823 18.3002 8.05823C18.1202 7.87823 18.0068 7.6249 18.0068 7.35156" stroke-miterlimit="10" />
            </svg>

          </Link>
        </div>
        <div className="px-5 2xl:px-10 mt-[60px] lg:mt-0">
          <BreadCrumb params={resolvedParams} />
        </div>

        {/* Search + Title */}
        {/* ===== Search + Categories ===== */}
        <div className="mb-10 mt-[-50px] lg:mt-5 space-y-7 ps-5">
          <div className="flex flex-col lg:flex-row lg:justify-between lg:items-center w-full px-5 lg:pe-4">
            <h1 className="font-rokh text-center md:text-start font-bold w-full lg:w-1/2 text-[24px] sm:text-[26px] md:text-[28px] lg:text-[30px] xl:text-[32px] dark:text-white mt-[64px] mb-[16px]">
              {findByUniqueId(mainData, 255)}
            </h1>
            <p className="lg:hidden text-matn-2 dark:text-matn-2 font-azarMehr text-center lg:text-start text-[16px] sm:text-[18px] md:text-[20px] lg:text-[22px] xl:text-[24px] px-5 2xl:pe-28">
              {findByUniqueId(mainData, 1629) || "رجع تخصصی و مرکز نشر آخرین رویدادها، پیشرفت‌های فنی و اخبار توسعه دنیای موازی متارنگ؛ آگاهی از تازه‌ترین تحولات در حوزه‌ی فناوری، تجارت مجازی و حاکمیت غیرمتمرکز با ساختار بین المللی."}
            </p>
            <SearchComponent
              searchLevel="news"
              mainData={mainData}
              params={resolvedParams}
            />
          </div>
          <p className="text-matn-2 hidden lg:block dark:text-matn-2 font-azarMehr text-center lg:text-start text-[16px] sm:text-[18px] md:text-[20px] lg:text-[22px] xl:text-[24px] px-5 2xl:pe-28">
            {findByUniqueId(mainData, 1629) || "رجع تخصصی و مرکز نشر آخرین رویدادها، پیشرفت‌های فنی و اخبار توسعه دنیای موازی متارنگ؛ آگاهی از تازه‌ترین تحولات در حوزه‌ی فناوری، تجارت مجازی و حاکمیت غیرمتمرکز با ساختار بین المللی."}
          </p>
        </div>

        <div className="space-y-28 mt-28">
          <BreakingNewsSlider mainData={mainData} lang={lang} news={allNews?.slice(0, 5) ?? []} />

          <LatestNews
            params={resolvedParams}
            mainData={mainData}
            initialNews={allNews as any}
          />

          <VideoNewsList
            params={resolvedParams}
            limit={6}
            title="اخبار ویدئویی داغ"
            mainData={mainData}
          />

          {/* بخش دسته‌بندی */}
          <NewsCategoriesSection
            lang={resolvedParams.lang}
            mainData={mainData}
            categories={categories}
            initialNewsByCategory={newsByCategory}
          />

          <PopularNews
            params={resolvedParams}
            mainData={mainData}
            initialNews={allNews.slice(0, 10) as any}
          />

          {/* خبرنامه */}
          <div id="em" className="w-full px-5 flex flex-col items-center">
            <svg xmlns="http://www.w3.org/2000/svg" width="364" height="364" viewBox="0 0 364 364" fill="none" className="mb-[-140px] dark:hidden">
              <path d="M333.666 174.419V235.086C333.666 288.169 303.333 310.919 257.833 310.919H106.166C60.6663 310.919 30.333 288.169 30.333 235.086V128.919C30.333 75.8359 60.6663 53.0859 106.166 53.0859H182" stroke="url(#paint0_linear_4633_15252)" strokeWidth="6" strokeMiterlimit="10" strokeLinecap="round" strokeLinejoin="round" />
              <path d="M106.167 136.5L166.834 174.417C182.728 186.394 211.606 171.228 227.5 159.25" stroke="url(#paint1_linear_4633_15252)" strokeWidth="6" strokeMiterlimit="10" strokeLinecap="round" strokeLinejoin="round" />
              <path d="M280.097 47.0625C264.099 47.0625 251.097 60.0642 251.097 76.0625V90.0308C251.097 92.9792 249.84 97.4742 248.342 99.9875L242.784 109.219C239.352 114.923 241.72 121.254 248.004 123.381C268.835 130.341 291.31 130.341 312.142 123.381C317.99 121.448 320.552 114.536 317.362 109.219L311.804 99.9875C310.354 97.4742 309.097 92.9792 309.097 90.0308V76.0625C309.097 60.1125 296.047 47.0625 280.097 47.0625Z" stroke="url(#paint2_linear_4633_15252)" strokeWidth="6" strokeMiterlimit="10" strokeLinecap="round" />
              <path d="M289.039 48.465C287.54 48.03 285.994 47.6917 284.399 47.4983C279.759 46.9183 275.312 47.2567 271.155 48.465C272.557 44.8883 276.037 42.375 280.097 42.375C284.157 42.375 287.637 44.8883 289.039 48.465Z" stroke="url(#paint3_linear_4633_15252)" strokeWidth="6" strokeMiterlimit="10" strokeLinecap="round" strokeLinejoin="round" />
              <path d="M294.597 125.125C294.597 133.1 288.072 139.625 280.097 139.625C276.133 139.625 272.46 137.982 269.85 135.372C267.24 132.762 265.597 129.088 265.597 125.125" stroke="url(#paint4_linear_4633_15252)" strokeWidth="6" strokeMiterlimit="10" />
              <defs>
                <linearGradient id="paint0_linear_4633_15252" x1="182" y1="53.0859" x2="182" y2="310.919" gradientUnits="userSpaceOnUse">
                  <stop stopColor="#00398E" />
                  <stop offset="1" stopColor="#9100D9" />
                </linearGradient>
                <linearGradient id="paint1_linear_4633_15252" x1="166.834" y1="136.5" x2="166.834" y2="178.788" gradientUnits="userSpaceOnUse">
                  <stop stopColor="#00398E" />
                  <stop offset="1" stopColor="#9100D9" />
                </linearGradient>
                <linearGradient id="paint2_linear_4633_15252" x1="279.977" y1="47.0625" x2="279.977" y2="128.601" gradientUnits="userSpaceOnUse">
                  <stop stopColor="#00398E" />
                  <stop offset="1" stopColor="#9100D9" />
                </linearGradient>
                <linearGradient id="paint3_linear_4633_15252" x1="280.097" y1="42.375" x2="280.097" y2="48.465" gradientUnits="userSpaceOnUse">
                  <stop stopColor="#00398E" />
                  <stop offset="1" stopColor="#9100D9" />
                </linearGradient>
                <linearGradient id="paint4_linear_4633_15252" x1="280.097" y1="125.125" x2="280.097" y2="139.625" gradientUnits="userSpaceOnUse">
                  <stop stopColor="#00398E" />
                  <stop offset="1" stopColor="#9100D9" />
                </linearGradient>
              </defs>
            </svg>
            <svg xmlns="http://www.w3.org/2000/svg" width="364" height="364" viewBox="0 0 364 364" fill="none" className="mb-[-140px] hidden dark:block">
              <path d="M333.667 174.419V235.086C333.667 288.169 303.334 310.919 257.834 310.919H106.167C60.6673 310.919 30.334 288.169 30.334 235.086V128.919C30.334 75.8359 60.6673 53.0859 106.167 53.0859H182.001" stroke="url(#paint0_linear_4633_15270)" strokeWidth="6" strokeMiterlimit="10" strokeLinecap="round" strokeLinejoin="round" />
              <path d="M106.166 136.5L166.833 174.417C182.727 186.394 211.605 171.228 227.499 159.25" stroke="url(#paint1_linear_4633_15270)" strokeWidth="6" strokeMiterlimit="10" strokeLinecap="round" strokeLinejoin="round" />
              <path d="M280.096 47.0625C264.098 47.0625 251.096 60.0642 251.096 76.0625V90.0308C251.096 92.9792 249.839 97.4742 248.341 99.9875L242.783 109.219C239.351 114.923 241.719 121.254 248.003 123.381C268.834 130.341 291.309 130.341 312.141 123.381C317.989 121.448 320.551 114.536 317.361 109.219L311.803 99.9875C310.353 97.4742 309.096 92.9792 309.096 90.0308V76.0625C309.096 60.1125 296.046 47.0625 280.096 47.0625Z" stroke="url(#paint2_linear_4633_15270)" strokeWidth="6" strokeMiterlimit="10" strokeLinecap="round" />
              <path d="M289.038 48.465C287.539 48.03 285.993 47.6917 284.398 47.4983C279.758 46.9183 275.311 47.2567 271.154 48.465C272.556 44.8883 276.036 42.375 280.096 42.375C284.156 42.375 287.636 44.8883 289.038 48.465Z" stroke="url(#paint3_linear_4633_15270)" strokeWidth="6" strokeMiterlimit="10" strokeLinecap="round" strokeLinejoin="round" />
              <path d="M294.596 125.125C294.596 133.1 288.071 139.625 280.096 139.625C276.132 139.625 272.459 137.982 269.849 135.372C267.239 132.762 265.596 129.088 265.596 125.125" stroke="url(#paint4_linear_4633_15270)" strokeWidth="6" strokeMiterlimit="10" />
              <defs>
                <linearGradient id="paint0_linear_4633_15270" x1="182.001" y1="53.0859" x2="182.001" y2="310.919" gradientUnits="userSpaceOnUse">
                  <stop stopColor="#997700" />
                  <stop offset="1" stopColor="#9100D9" />
                </linearGradient>
                <linearGradient id="paint1_linear_4633_15270" x1="166.833" y1="136.5" x2="166.833" y2="178.788" gradientUnits="userSpaceOnUse">
                  <stop stopColor="#997700" />
                  <stop offset="1" stopColor="#9100D9" />
                </linearGradient>
                <linearGradient id="paint2_linear_4633_15270" x1="279.976" y1="47.0625" x2="279.976" y2="128.601" gradientUnits="userSpaceOnUse">
                  <stop stopColor="#997700" />
                  <stop offset="1" stopColor="#9100D9" />
                </linearGradient>
                <linearGradient id="paint3_linear_4633_15270" x1="280.096" y1="42.375" x2="280.096" y2="48.465" gradientUnits="userSpaceOnUse">
                  <stop stopColor="#997700" />
                  <stop offset="1" stopColor="#9100D9" />
                </linearGradient>
                <linearGradient id="paint4_linear_4633_15270" x1="280.096" y1="125.125" x2="280.096" y2="139.625" gradientUnits="userSpaceOnUse">
                  <stop stopColor="#997700" />
                  <stop offset="1" stopColor="#9100D9" />
                </linearGradient>
              </defs>
            </svg>
            <div className="bg-white dark:bg-[#0E0E0E] w-full max-w-7xl rounded-xl py-10 2xl:py-12 px-5 2xl:px-10 text-center flex flex-col items-center gap-4 mx-auto">
              <p className="text-2xl dark:text-white 2xl:text-[32px] font-rokh dark:text-wrap font-bold">{findByUniqueId(mainData, 1626) || "خبرنامه متاورس"}</p>
              <p className="lg:text-lg dark:text-[#868B90] text-[#656565]">{findByUniqueId(mainData, 1627) || "برای اطلاع از آخرین اخبار، تحلیل ها و مطالب اختصاصی، می توانید در خبرنامه ما عضو شوید.هدف ما ارائه محتوای دقیق، معتبر و به روز است تا همواره از مهم ترین تحولات باخبر باشید. در صورت تمایل، کافی است آدرس ایمیل خود را وارد کنید تا از این پس، به روزترین محتواها و اطلاع رسانی های رسمی را بدون نیاز به مراجعه مداوم به وب سایت، دریافت کنید."}</p>
              <div className="w-full flex flex-col gap-2 gap-y-5 lg:flex-row max-w-3xl">
                <input type="text" name="" placeholder={findByUniqueId(mainData, 1626) || "آدرس ایمیل"} className="bg-[#F5F5F5] w-full lg:w-[75%]  rounded-xl border-0 ring-1 ring-[#D9D9D9] dark:ring-[#434343] px-4 py-2 focus:outline-hidden focus:ring-2 focus:ring-primary focus: focus:ring-offset-2 focus:ring-offset-white dark:focus:ring-offset-gray-1" />
                <button className="bg-primary font-bold text-black rounded-xl px-5 py-2 lg:w-[25%]">{findByUniqueId(mainData, 2)}</button>
              </div>
            </div>
          </div>
        </div>
      </section>
    );
  } catch (error) {
    console.error("❌ Error in NewsPage:", error);
    const serializedError = {
      message: error instanceof Error ? error.message : "Unknown error",
      stack: error instanceof Error ? error.stack : null,
      name: error instanceof Error ? error.name : "Error",
    };
    return <CustomErrorPage error={serializedError} />;
  }
}