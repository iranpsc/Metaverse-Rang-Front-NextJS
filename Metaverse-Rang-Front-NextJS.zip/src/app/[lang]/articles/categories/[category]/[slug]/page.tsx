export const dynamic = "force-dynamic";

import NotFoundPage from "@/components/error/NotFoundPage";
import { supabase } from "@/utils/lib/supabaseClient";

import {
  getTranslation,
  getMainFile,
  getLangArray,
} from "@/components/utils/actions";
import BreadCrumb from "@/components/shared/BreadCrumb";

import AuthorSection from "@/components/ui/weblog/AuthorSection";
import ArticleHeader from "@/components/ui/header/ArticleHeader";
import ArticleImage from "@/components/ui/ArticleImage";
import ArticleContent from "@/components/ui/weblog/ArticleContent";
import SideCard from "@/components/card/ArticleSideBarCard";
import PopularArticlesSlider from "@/components/shared/slider/PopularArticlesSlider";
import RelatedArticlesSlider from "@/components/features/RelatedArticlesSlider";
import PrevNextArticles from "@/components/features/PrevNextArticles";
import AuthorCard from "@/components/card/AuthorCard";
import ShowSocialWrapper from "@/components/shared/ShowSocialWrapper";
import CustomErrorPage from "@/components/error/CustomErrorPage";
import CleanAutoRetryParam from "@/components/system/CleanAutoRetryParam";
import { findByUniqueId } from "@/components/utils/findByUniqueId";

interface ArticlePageProps {
  
  params: Promise<{
    lang: string; category: string;
    slug: string;
  }>;
}
// ======================================
// Metadata (SEO + 404 امن)
// ======================================
export async function generateMetadata({ params  }: ArticlePageProps) {
  const resolvedParams = await params;
  const { lang } = resolvedParams;
    const [ langData ] = await Promise.all([
    getTranslation(lang),

  ]);
  const mainData = await getMainFile(langData);
  try {
    function cleanDescription(html: any, limit = 155) {
      if (!html) return "";

      let text = "";

      if (typeof window === "undefined") {
        // SSR / Node.js
        text = html.replace(/<|>/g, "");
      } else {
        // Browser
        const div = document.createElement("div");
        div.innerHTML = html;
        text = div.textContent || div.innerText || "";
      }

      text = text.trim();

      return text.length > limit
        ? text.slice(0, limit).trim() + "…"
        : text;
    }

    const { slug, category, lang } = resolvedParams;

    const { data: article } = await supabase
      .from("articles")
      .select("*")
      .eq("slug", slug)
      .single();

    if (!article) {
      return {
        title: "مقاله یافت نشد",
        description: "مقاله مورد نظر وجود ندارد",
        robots: { index: false, follow: false },
      };
    }

    if (category !== article.categorySlug) {
      return {
        title: "مقاله یافت نشد",
        description: "آدرس مقاله معتبر نیست",
        robots: { index: false, follow: false },
      };
    }

    const canonicalUrl = `https://metarang.com/${lang}/articles/categories/${article.categorySlug}/${article.slug}`;

    return {
      title: `${article.title} | ${findByUniqueId(mainData, 148)}`,
      description: cleanDescription(article.description || "مقالات متاورس رنگ"),
      alternates: { canonical: canonicalUrl },
      openGraph: {
        title: article.title,
        description: cleanDescription(article.description || "مقالات متاورس رنگ"),
        url: canonicalUrl,
        type: "article",
        images: article.image ? [{ url: article.image }] : [],
      },
      twitter: {
        card: "summary_large_image",
        title: article.title,
        description: cleanDescription(article.description || "مقالات متاورس رنگ"),
        images: article.image ? [article.image] : [],
      },
      robots: { index: true, follow: true },
    };
  } catch (error) {
    console.error("❌ Metadata error (LevelsPage):", error);

    return {
      title: "خطا",
      description: "مشکلی در بارگذاری صفحه رخ داده است",
    };
  }
}

// ======================================
// Static Paths - مهم برای رفع ۴۰۴ اولیه
// ======================================
export async function generateStaticParams() {
  try {
    const { data: articles } = await supabase
      .from("articles")
      .select("categorySlug, slug")
      // اگر فیلد وضعیت انتشار دارید، حتماً اضافه کنید:
      // .eq("status", "published")
      // .eq("is_active", true)
      .limit(500); // برای جلوگیری از timeout در build (در صورت نیاز بیشتر کنید یا صفحه‌بندی کنید)

    if (!articles?.length) return [];

    // اگر فقط یک زبان دارید (مثلاً فقط فارسی):
    return articles.map((article) => ({
      lang: "fa", // ← زبان پیش‌فرض خودتون رو اینجا بذارید
      category: article.categorySlug,
      slug: article.slug,
    }));

    // اگر چندزبانه دارید، به این شکل تغییر بدید:
    /*
    const languages = ["fa", "en"];
    return languages.flatMap((lang) =>
      articles.map((article) => ({
        lang,
        category: article.categorySlug,
        slug: article.slug,
      }))
    );
    */
  } catch (error) {
    console.error("Error generating static params:", error);
    return [];
  }
}




export const dynamicParams = true; // اجازه می‌ده مقالات جدید بدون rebuild هم کار کنن

// ======================================
// صفحه اصلی مقاله
// ======================================
export default async function ArticlePage({ params } :ArticlePageProps) {
     const resolvedParams = await params;
  // const { lang } = resolvedParams;
  try {
    function cleanDescription(html: any, limit = 150) {
      if (!html) return "";

      // Normalize to string
      let text = String(html);

      // Remove any angle brackets to prevent partial tags (e.g., "<script")
      text = text.replace(/[<>]/g, "");

      // Collapse consecutive whitespace and trim
      text = text.replace(/\s+/g, " ").trim();

      return text.length > limit
        ? text.slice(0, limit).trim() + "…"
        : text;
    }



    const { slug, category, lang } = resolvedParams;

    // مقاله اصلی
    const { data: article, error: articleError } = await supabase
      .from("articles")
      .select("*")
      .eq("slug", slug)
      .single();

    if (articleError || !article) {
      const [langData, langArray, mainData] = await Promise.all([
        getTranslation(lang),
        getLangArray(),
        getMainFile(await getTranslation(lang)),
      ]);

      return (
        <NotFoundPage
          lang={lang}
          params={resolvedParams}
          langData={langData}
          langArray={langArray}
          // footerTabs={[]}
          mainData={mainData}
        />
      );
    }

    // چک کردن category
    if (category !== article.categorySlug) {
      const [langData, langArray, mainData] = await Promise.all([
        getTranslation(lang),
        getLangArray(),
        getMainFile(await getTranslation(lang)),
      ]);

      return (
        <NotFoundPage
          lang={lang}
          params={resolvedParams}
          langData={langData}
          langArray={langArray}
          // footerTabs={[]}
          mainData={mainData}
        />
      );
    }

    // مقالات همان دسته برای Prev/Next
    const { data: categoryArticles } = await supabase
      .from("articles")
      .select("*")
      .eq("categorySlug", article.categorySlug)
      .order("date", { ascending: true });

    const [langData, mainData] = await Promise.all([
      getTranslation(lang),
      getMainFile(await getTranslation(lang)),
    ]);

    const relatedArticles = (categoryArticles || [])
      .filter(
        (a: any) =>
          a.slug !== article.slug &&
          (a.category === article.category ||
            a.subCategory === article.subCategory ||
            a.categorySlug === article.categorySlug)
      )
      .slice(0, 10);

    // JSON-LD Schema
    const schema = {
      "@context": "https://schema.org",
      "@type": "Article",
      headline: article.title,
      description: cleanDescription(article.description || "مقالات متاورس رنگ"),
      image: article.image ? [article.image] : undefined,
      author: {
        "@type": "Person",
        name: article.author?.name ?? "نویسنده",
      },
      datePublished: article.date,
      mainEntityOfPage: {
        "@type": "WebPage",
        "@id": `https://metarang.com/${lang}/articles/categories/${category}/${slug}`,
      },
      publisher: {
        "@type": "Organization",
        name: "متاورس رنگ",
        logo: {
          "@type": "ImageObject",
          url: "https://s3.metarang.com/metarang/logo/metarang-logo-512.png",
        },
      },
    };

    return (
      <div className="w-full  relative bg-bg-primary " dir={langData.direction}>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }}
        />
        <CleanAutoRetryParam />
        <section className="w-full  relative bg-bg-primary  mt-[60px] lg:mt-0">
          <div className="px-5 2xl:px-10">
            <BreadCrumb params={resolvedParams} title={article.title} articleCat={article.category} />
          </div>

          <div className="mainContainer w-full flex flex-col gap-5 items-center lg:flex-row lg:items-start px-5 lg:px-10">
            {/* محتوای اصلی */}
            <div className="lg:w-[70%] 3xl:w-[80%]">
              <div className="flex flex-col gap-10 w-full items-center rounded-xl bg-white dark:bg-gray-1  shadow-lg p-5 xl:p-10">
                <AuthorSection
                  author={article.author}
                  date={article.date}
                  excerpt={article.excerpt}
                  title={article.title}
                  content={article.content}
                  stats={article.stats}
                  mainData={mainData}
                  lang={lang}
                />

                <ArticleHeader
                  title={article.title}
                  author={article.author}
                  date={article.date}
                  description={article.description}
                />

                <ArticleImage article={article} mainData={mainData} />

                <ArticleContent content={article.content} tags={article.tags} />
              </div>

              <div className="w-full mt-10 space-y-28">
                <ShowSocialWrapper params={resolvedParams} mainData={mainData} content={article} />
                <PrevNextArticles params={resolvedParams} articles={categoryArticles || []} mainData={mainData} />
                <AuthorCard lang={lang} article={article} mainData={mainData} />
              </div>
            </div>

            {/* سایدبار */}
            <div className="w-full hidden lg:block lg:w-[30%] 3xl:w-[20%] sticky top-5">
              <SideCard params={resolvedParams} mainData={mainData} />
            </div>
          </div>

          {/* اسلایدرها */}
          <div className="ps-5 lg:ps-10 w-full flex items-center mt-14 lg:mt-20 flex-col gap-14">
            <PopularArticlesSlider params={resolvedParams} mainData={mainData} />
            <RelatedArticlesSlider
              params={resolvedParams}
              mainData={mainData}
              initialArticles={relatedArticles}
            />
          </div>
        </section>
      </div>
    );
  }
  catch (error) {
    const serializedError = {
      message:
        error instanceof Error ? error.message : "Unknown error",
      stack:
        error instanceof Error ? error.stack : null,
      name:
        error instanceof Error ? error.name : "Error",
    };

    console.error("❌ Error in ArticlePage:", serializedError);

    return <CustomErrorPage error={serializedError} />;
  }
}