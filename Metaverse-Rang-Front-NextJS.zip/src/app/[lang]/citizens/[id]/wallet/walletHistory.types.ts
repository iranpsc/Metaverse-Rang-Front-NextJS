import { findByUniqueId } from "@/components/utils/findByUniqueId";

export type Period = "daily" | "weekly" | "monthly" | "yearly";

export interface SummaryItem {
  asset: string;
  current_balance: number;
  direction: "up" | "down";
  growth_percent: number;
  period_income: number;
  period_spending: number;
  privacy_restricted: boolean;
}

export interface ChartPoint {
  amount: number;
  label: string;
}

export interface ChartAssetData {
  income: ChartPoint[];
  spending: ChartPoint[];
}

export type AssetIconType =
  | "trophy"
  | "diamond"
  | "flag"
  | "coin"
  | "gauge"
  | "blueGem"
  | "yellowSparkle"
  | "banknote";

/* ------------------------------------------------------------------ */
/*                         ASSET CONFIG                                */
/* ------------------------------------------------------------------ */

export const ASSET_CONFIG: Record<
  string,
  {
    label: string;
    color: string;
    icon: AssetIconType;
    uniqueId: number;
    href?: string;
  }
> = {
  blue: {
    label: "رنگ آبی",
    color: "#0066ff",
    icon: "blueGem",
    uniqueId: 49,
    href: "https://dev-nextjs.metarang.com/fa/articles/categories/rang/BL_10002",
  },

  red: {
    label: "رنگ قرمز",
    color: "#EF4444",
    icon: "flag",
    uniqueId: 12,
    href: "https://dev-nextjs.metarang.com/fa/articles/categories/rang/BL_10003",
  },

  yellow: {
    label: "رنگ زرد",
    color: "#EAB600",
    icon: "yellowSparkle",
    uniqueId: 11,
    href: "https://dev-nextjs.metarang.com/fa/articles/categories/rang/BL_10001",
  },

  satisfaction: {
    label: "واحد رضایت",
    color: "#A78BFA",
    icon: "trophy",
    uniqueId: 453,
  },

  irr: {
    label: "ارز ریال",
    color: "#22C55E",
    icon: "banknote",
    uniqueId: 1579,
  },

  effect: {
    label: "حد تاثیر",
    color: "#38BDF8",
    icon: "gauge",
    uniqueId: 723,
    href: "https://dev-nextjs.metarang.com/fa/articles/categories/digital-governance-and-the-citizen-economy/BL_10014",
  },

  psc: {
    label: "ارز Pcs",
    color: "#9100D9",
    icon: "coin",
    uniqueId: 1578,
  },
};

export const ASSET_ORDER = Object.keys(ASSET_CONFIG);

/* ------------------------------------------------------------------ */
/*                         ASSET LABEL                                 */
/* ------------------------------------------------------------------ */

export function getAssetLabel(
  mainData: any,
  assetKey: string,
): string {
  const config = ASSET_CONFIG[assetKey];

  if (!config) {
    return assetKey;
  }

  const fromMainData = findByUniqueId(
    mainData,
    config.uniqueId,
  );

  return fromMainData || config.label;
}

/* ------------------------------------------------------------------ */
/*                         PERIOD OPTIONS                              */
/* ------------------------------------------------------------------ */

export const PERIOD_OPTIONS: {
  key: Period;
  uniqueId: number;
  fallback: string;
}[] = [
  {
    key: "daily",
    uniqueId: 1429,
    fallback: "روزانه",
  },
  {
    key: "weekly",
    uniqueId: 1430,
    fallback: "هفتگی",
  },
  {
    key: "monthly",
    uniqueId: 1431,
    fallback: "ماهانه",
  },
  {
    key: "yearly",
    uniqueId: 1432,
    fallback: "سالانه",
  },
];

/* ------------------------------------------------------------------ */
/*                    PERIOD EARNED LABELS                            */
/* ------------------------------------------------------------------ */

export const PERIOD_EARNED_UNIQUE_IDS: Record<Period, number> = {
  daily: 1817,
  weekly: 1818,
  monthly: 1819,
  yearly: 1820,
};

export const PERIOD_EARNED_FALLBACKS: Record<Period, string> = {
  daily: "درآمد روزانه",
  weekly: "درآمد هفتگی",
  monthly: "درآمد هفتگی",
  yearly: "درآمد سالانه",
};

export function getPeriodEarnedLabel(
  mainData: any,
  period: Period,
): string {
  const uniqueId = PERIOD_EARNED_UNIQUE_IDS[period];

  const fromMainData = findByUniqueId(
    mainData,
    uniqueId,
  );

  return (
    fromMainData ||
    PERIOD_EARNED_FALLBACKS[period]
  );
}

export function getPeriodEarnedLabels(
  mainData: any,
): Record<Period, string> {
  return {
    daily: getPeriodEarnedLabel(mainData, "daily"),
    weekly: getPeriodEarnedLabel(mainData, "weekly"),
    monthly: getPeriodEarnedLabel(mainData, "monthly"),
    yearly: getPeriodEarnedLabel(mainData, "yearly"),
  };
}

/* ------------------------------------------------------------------ */
/*                              CARD                                   */
/* ------------------------------------------------------------------ */

export const CARD_HEIGHT = "h-[220px] lg:h-[240px]";