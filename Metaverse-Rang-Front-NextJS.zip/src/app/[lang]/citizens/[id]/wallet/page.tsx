import SideBar from "@/components/shared/sidebar/SideBar";
import BreadCrumb from "@/components/shared/BreadCrumb";
import NotFoundPage from "@/components/error/NotFoundPage";
import DynamicFooter from "@/components/shared/footer/DynamicFooter";
import CustomErrorPage from "@/components/error/CustomErrorPage";
import CleanAutoRetryParam from "@/components/system/CleanAutoRetryParam";
import WalletHistoryLoader from "./WalletHistoryLoader";

import {
  getTranslation,
  getMainFile,
  getLangArray,
  getUserData,
} from "@/components/utils/actions";
import { buildSidebarLabels } from "@/components/utils/buildShellTranslations";

import { getStaticMenu } from "@/components/utils/constants";
import { buildTabsMenu } from "@/components/utils/buildTabsMenu";
import InviteBox from "@/components/templates/referral/invite-box";
import { findByUniqueId } from "@/components/utils/findByUniqueId";

/* ------------------------------------------------------------------ */
/*                                TYPES                               */
/* ------------------------------------------------------------------ */
interface CitizenWalletHistoryProps {

  params: Promise<{
    lang: string;
    id: string;
  }>;
}

/* ------------------------------------------------------------------ */
/*                                PAGE                                */
/* ------------------------------------------------------------------ */
export default async function CitizenWalletHistory({
  params,

}: CitizenWalletHistoryProps) {
  const resolvedParams = await params;
  const { lang, id } = resolvedParams;

  try {
    /* --------------------------- base data --------------------------- */
    const [langData, profileData] = await Promise.all([
      getTranslation(lang),
      getUserData(id),
    ]);

    /* ------------------------ build sidebar -------------------------- */
    function buildUpdatedTabsMenu(mainData: any) {
      return buildTabsMenu(mainData, getStaticMenu(resolvedParams));
    }

    /* ---------------------------- not found -------------------------- */
    if (!profileData?.data) {
      const [mainData, langArray] = await Promise.all([
        getMainFile(langData),
        getLangArray(),
      ]);

      return (
        <NotFoundPage
          lang={lang}
          params={resolvedParams}
          langData={langData}
          langArray={langArray}
          mainData={mainData}
        />
      );
    }

    /* ------------------------- page data ----------------------------- */
    const [mainData, langArray] = await Promise.all([
      getMainFile(langData),
      getLangArray(),
    ]);

    const updatedTabsMenu = buildUpdatedTabsMenu(mainData);
    const sidebarLabels = buildSidebarLabels(mainData);

    /* ------------------------- JSON-LD schema ------------------------- */
    const isFa = lang === "fa";

    const kyc = profileData?.data?.kyc;
    const fullName = kyc?.fname
      ? `${kyc.fname} ${kyc.lname}`
      : profileData?.data?.name || (isFa ? "شهروند" : "Citizen");

    const canonicalUrl = `https://metarang.com/${lang}/citizens/${id}/wallet-history`;

    const jsonLd = {
      "@context": "https://schema.org",
      "@graph": [
        {
          "@type": "WebPage",
          "@id": canonicalUrl,
          url: canonicalUrl,
          name: isFa
            ? `تاریخچه دارایی‌های ${fullName} | ${findByUniqueId(mainData, 148)}`
            : `Wallet history of ${fullName} | ${findByUniqueId(mainData, 148)}`,
          description: isFa
            ? "جدول و نمودار تاریخچه دارایی‌های کاربر"
            : "Citizen wallet asset history summary and chart",
          inLanguage: isFa ? "fa-IR" : "en-US",
          isPartOf: {
            "@type": "WebSite",
            name: "Metarang",
            url: "https://metarang.com",
          },
          about: {
            "@type": "Person",
            name: fullName,
            url: `https://metarang.com/${lang}/citizens/${id}`,
          },
        },
        {
          "@type": "BreadcrumbList",
          itemListElement: [
            {
              "@type": "ListItem",
              position: 1,
              name: isFa ? "خانه" : "Home",
              item: `https://metarang.com/${lang}`,
            },
            {
              "@type": "ListItem",
              position: 2,
              name: isFa ? "کاربران" : "Citizens",
              item: `https://metarang.com/${lang}/citizens`,
            },
            {
              "@type": "ListItem",
              position: 3,
              name: fullName,
              item: `https://metarang.com/${lang}/citizens/${id}`,
            },
            {
              "@type": "ListItem",
              position: 4,
              name: isFa ? "تاریخچه دارایی‌ها" : "Wallet History",
              item: canonicalUrl,
            },
          ],
        },
      ],
    };

    /* ----------------------------- render ---------------------------- */
    return (
      <>
        <CleanAutoRetryParam />

        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />

        <div
          className="flex h-screen overflow-hidden"
          dir={langData.direction}
        >
          <SideBar
            tabsMenu={updatedTabsMenu}
            langData={langData}
            langArray={langArray}
            params={resolvedParams}
            pageSide="citizen"
            sidebarLabels={sidebarLabels}
          />

          <section className="relative w-full overflow-y-auto mt-[60px] lg:mt-0 bg-bg-primary  px-2 light-scrollbar dark:dark-scrollbar">
            <div className="px-12">
              <BreadCrumb params={resolvedParams} />
            </div>

            <div className="xl:px-8 lg:px-8 md:px-5 sm:px-5 xs:px-1">
                <InviteBox
                params={resolvedParams}
                mainData={mainData}
                imageLight="https://s3.metarang.com/metarang/asset/wallet-light.png"
                imageDark="https://s3.metarang.com/metarang/asset/wallet-dark.png"
                descriptionId={1575}
                urlSuffix="wallet"
              />
              <WalletHistoryLoader params={resolvedParams} mainData={mainData} />
            </div>

            <div className="xl:px-8 lg:px-8 md:px-5 sm:px-5 xs:px-1">
              <DynamicFooter mainData={mainData} params={resolvedParams} />
            </div>
          </section>
        </div>
      </>
    );
  } catch (error) {
    const serializedError = {
      message: error instanceof Error ? error.message : "Unknown error",
      stack: error instanceof Error ? error.stack : null,
      name: error instanceof Error ? error.name : "Error",
    };

    console.error("❌ Error in CitizenWalletHistory:", serializedError);
    return <CustomErrorPage error={serializedError} />;
  }
}

/* ------------------------------------------------------------------ */
/*                                SEO                                 */
/* ------------------------------------------------------------------ */
export async function generateMetadata({
  params,
}: {
  params: Promise<{ lang: string; id: string  }>;
}) {
  const { lang, id } = await params;
  const isFa = lang === "fa";
  const [ langData] = await Promise.all([
    getTranslation(lang),
  ]);
  const mainData = await getMainFile(langData);
  try {
    const profileData = await getUserData(id);

    if (!profileData?.data) {
      return {
        title: isFa ? "404 - پیدا نشد" : "404 - Not found",
        description: isFa
          ? "صفحه مورد نظر یافت نشد"
          : "The requested page could not be found",
        robots: { index: false, follow: false },
      };
    }

    const fullName = profileData.data?.kyc?.fname
      ? `${profileData.data.kyc.fname} ${profileData.data.kyc.lname}`
      : profileData.data.name || (isFa ? "شهروند" : "Citizen");

    const title = isFa
      ? `تاریخچه دارایی‌های ${fullName} | ${findByUniqueId(mainData, 148)}`
      : `Wallet history of ${fullName} | ${findByUniqueId(mainData, 148)} `;

    const description = isFa
      ? "جدول و نمودار تاریخچه دارایی‌های کاربر"
      : "Citizen wallet asset history summary and chart";

    const canonicalUrl = `https://metarang.com/${lang}/citizens/${id}/wallet-history`;
    const ogImage =
      profileData.data?.profilePhotos?.[0]?.url || "https://s3.metarang.com/metarang/logo/metarang-logo-512.png";

    return {
      title,
      description,
      keywords: isFa
        ? [fullName, "تاریخچه دارایی", "کیف پول", "متاورس رنگ", profileData.data.code]
        : [fullName, "wallet history", "asset history", "Metarang metaverse", profileData.data.code],
      alternates: {
        canonical: canonicalUrl,
        languages: {
          "fa-IR": `https://metarang.com/fa/citizens/${id}/wallet-history`,
          "en-US": `https://metarang.com/en/citizens/${id}/wallet-history`,
          "x-default": `https://metarang.com/fa/citizens/${id}/wallet-history`,
        },
      },
      openGraph: {
        type: "website",
        title,
        description,
        locale: isFa ? "fa_IR" : "en_US",
        url: canonicalUrl,
        siteName: "Metarang",
        images: [
          {
            url: ogImage,
            width: 800,
            height: 600,
          },
        ],
      },
      twitter: {
        card: "summary_large_image",
        title,
        description,
        images: [ogImage],
      },
    };
  } catch {
    return {
      title: isFa ? "خطا" : "Error",
      description: isFa
        ? "مشکلی در بارگذاری صفحه رخ داده است"
        : "An error occurred while loading the page",
    };
  }
}