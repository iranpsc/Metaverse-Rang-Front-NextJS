import Image from "next/image";
import { ShowAll } from "@/components/svgs/SvgEducation";
import Link from "next/link";
import { findByUniqueId } from "@/components/utils/findByUniqueId";

export default function EducationCategories({
  categoriesData,
  mainData,
  params,
}: any) {
  return (
    <>
      <div className="w-[95%] mx-auto h-fit mt-36 flex flex-col justify-center items-center ">
        <h1 className="w-full font-azarMehr font-medium text-[16px] md:text-[20px] lg:text-[28px] xl:text-[32px] dark:text-white">
          {findByUniqueId(mainData, 270)}
        </h1>

        <div className="mt-10 grid 2xl:grid-cols-5 xl:grid-cols-5 lg:grid-cols-3 md:grid-cols-2 sm:grid-cols-2 xs:grid-cols-2 sm:place-items-center xs:place-items-center xs:gap-x-3 w-full gap-3">
          {categoriesData &&
            categoriesData.slice(0, 9).map((item: any) => ( // فقط ۹ تا
              <Link
                href={`/${params.lang}/education/category/${item.slug}`}
                key={item.id}
                className="col-span-1 cursor-pointer shadow-xs dark:hover:shadow-dark transition-all duration-300 2xl:w-full xl:w-full lg:w-full md:w-full sm:w-[200px] xs:w-full h-[80px] bg-white dark:bg-gray-1  rounded-[20px] flex flex-row justify-start items-center gap-5 xs:gap-2 hover:shadow-md"
              >
                <Image
                  className="w-[32px] h-[32px] xs:w-[28px] xs:h-[28px] ms-3 stroke-matn-2"
                  style={{ filter: 'invert(47%) sepia(3%) saturate(9%) hue-rotate(167deg) brightness(67%) contrast(82%)' }}
                  src={item.icon}
                  alt={item.slug}
                  width={1000}
                  height={1000}
                />
                <p className="dark:text-white text-black text-[18px] xs:text-[13px] font-medium font-azarMehr xs:max-w-[85px] text-center">
                  {params.lang == "fa" ? item.name : item.slug}
                </p>
              </Link>
            ))}

          <Link
            href={`/${params.lang}/education/category`}
            className="col-span-1 cursor-pointer 2xl:w-full xl:w-full lg:w-full md:w-full sm:w-[200px] xs:w-full h-[80px] bg-white dark:bg-gray-1  rounded-[20px] flex flex-row justify-start items-center gap-5 shadow-xs hover:shadow-md"
          >
            <ShowAll className="w-[18px] h-[18px] stroke-primary ms-3 dark:dark:stroke-primary" />
            <p className="text-[18px] xs:text-[13px] font-medium text-primary  font-azarMehr xs:max-w-[85px] text-center">
              {findByUniqueId(mainData, 170)}
            </p>
          </Link>
        </div>
      </div>
    </>
  );
}
