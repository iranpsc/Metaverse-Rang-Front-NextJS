"use client";

import React, { useEffect, useRef, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { supabase } from "@/utils/lib/supabaseClient";
import { Calender, Timer } from "@/components/svgs/SvgEducation";
import { findByUniqueId } from "@/components/utils/findByUniqueId";
import { loadNewsFallback } from "@/components/utils/loadNewsFallback";


interface VideoItem {
  id: string | number;
  title: string;
  slug: string;
  image?: string;
  video: string;
  date?: string;
  readingTime?: number;
  categorySlug?: string;
}

type MainData = Record<string, unknown> | null;

interface Props {
  params: { lang: string };
  mainData: MainData;
  limit?: number;
  title?: string;
  date?: string;
}

export default function VideoNewsInlinePlayer({
  params,
  mainData,
  limit = 6,
}: Props) {
  const [videos, setVideos] = useState<VideoItem[]>([]);
  const [active, setActive] = useState<VideoItem | null>(null);
  const [hasPlayed, setHasPlayed] = useState(false);
  const videoRef = useRef<HTMLVideoElement | null>(null);

  useEffect(() => {
    const fetchVideos = async () => {
      // تلاش برای دریافت از Supabase
      const { data, error } = await supabase
        .from("news")
        .select("id, title, slug, image, video, date, readingTime, categorySlug")
        .neq("video", "")
        .not("video", "is", null)
        .order("date", { ascending: false })
        .limit(limit);

      // اگر خطایی رخ داد یا دیتایی نیامد، از fallback استفاده کن
      if (error || !data || data.length === 0) {
        if (error) {
          console.warn("⚠️ VideoNews: Supabase error, using fallback news.json", error.message);
        } else if (!data || data.length === 0) {
          console.warn("⚠️ VideoNews: No data from Supabase, using fallback news.json");
        }
        
        // استفاده از دیتای fallback و فیلتر کردن خبرهایی که ویدئو دارند
        const fallbackData = (await loadNewsFallback())
          .filter((item: any) => item.video && item.video !== "" && item.video !== null)
          .map((item: any) => ({
            id: item.id,
            title: item.title,
            slug: item.slug,
            image: item.image,
            video: item.video,
            date: item.date,
            readingTime: item.readingTime ? parseInt(item.readingTime, 10) : undefined,
            categorySlug: item.categorySlug,
          }))
          .sort((a, b) => {
            // مرتب‌سازی بر اساس تاریخ (جدیدترین اول)
            const dateA = a.date ? parseInt(a.date.replace(/\//g, "")) : 0;
            const dateB = b.date ? parseInt(b.date.replace(/\//g, "")) : 0;
            return dateB - dateA;
          })
          .slice(0, limit);
        
        if (fallbackData.length) {
          setVideos(fallbackData);
          setActive(fallbackData[0]);
          setHasPlayed(false);
        }
        return;
      }

      if (data?.length) {
        setVideos(data);
        setActive(data[0]);
        setHasPlayed(false);
      }
    };

    fetchVideos();
  }, [limit]);

  // autoplay فقط بعد از play
  useEffect(() => {
    if (hasPlayed && videoRef.current) {
      videoRef.current.play().catch((error) => {
        console.warn("Video autoplay failed:", error);
      });
    }
  }, [hasPlayed, active]);

  if (!active) return null;

  return (
    <section className="w-full bg-white dark:bg-[#0b0b0b] py-10 lg:py-20">
      <div className="w-full max-w-7xl p-3 xl:p-0 mx-auto">
        <h3 className="text-2xl 2xl:text-[32px] font-rokh font-bold dark:text-white mb-10 w-max border border-x-0 border-b-4 pe-7 border-t-0 pb-3 border-primary  border-solid">
          {findByUniqueId(mainData, 1618) || "اکنون تماشا کنید"}
        </h3>

        <div className="grid grid-cols-1 lg:grid-cols-[1fr_2fr] gap-5">
          <div>
           
              <div className="bg-primary/60 /70 flex">
                <Link href={`/${params.lang}/news/categories/${active.categorySlug}/${active.slug}`}>
                  <h2 className="text-white text-lg font-bold dark:text-gray-1  p-4">
                    {active.title}
                  </h2>
                </Link>
                <div className=" bg-primary">
                  <button onClick={() => setHasPlayed(true)} aria-label="play btn" className="bg-transparent py-3! p-6 w-max h-max text-center flex items-center justify-center aspect-square hover:scale-110 transition">
                    <svg width="87" height="87" viewBox="0 0 87 87" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <rect width="86.7799" height="86.7799" rx="43.39" fill="#1A1A18" fillOpacity="0.2" />
                      <path d="M62 37.3038C66 39.6132 66 45.3868 62 47.6962L37.25 61.9856C33.25 64.295 28.25 61.4082 28.25 56.7894L28.25 28.2106C28.25 23.5918 33.25 20.705 37.25 23.0144L62 37.3038Z" fill="white" />
                    </svg>
                  </button>
                </div>
              </div>
           
            {/* SIDE LIST */}
            <div className="space-y-3 max-h-[385px] light-scrollbar dark:dark-scrollbar overflow-y-auto pe-1">
              {videos.map((item) => {
                const isActive = item.id === active?.id;

                return (
                  <div 
                    onClick={() => {
                      setActive(item);
                      setHasPlayed(false);
                    }}
                    key={item.id}
                    className={`flex gap-3 p-2 transition
                      ${isActive ? "bg-primary/10 bg-primary/10" : "hover:bg-white/5"}`}
                  >
                    {item.image && (
                      <div className="relative w-1/3 aspect-video">
                        <Image
                          src={item.image}
                          alt={"video side " + item.title}
                          fill
                          sizes="(max-width: 768px) 33vw, 20vw"
                          loading="lazy"
                          quality={60}
                          className="object-cover rounded-lg"
                          unoptimized={true}
                        />
                      </div>
                    )}
                    {/* TITLE */}
                    <div className="flex flex-col justify-between w-2/3 text-right py-1 ps-1">
                      {isActive && hasPlayed ? (
                        <Link href={`/${params.lang}/news/categories/${item.categorySlug}/${item.slug}`}>
                          <p className="text-sm line-clamp-2 text-primary  hover:underline">
                            {item.title}
                          </p>
                        </Link>
                      ) : (
                        <p className="text-sm line-clamp-2 text-black dark:text-white">
                          {item.title}
                        </p>
                      )}
                      <div className="text-sm dark:text-[#969696] flex flex-wrap items-center gap-3 justify-center lg:justify-start">
                        {item.date && (
                          <div className="flex items-center gap-2">
                            <time>
                            {item.date?.split("T")[0]}
                            </time>
                            <Calender className="stroke-dark-gray stroke-0! size-5" />
                          </div>
                        )}
                        {item.readingTime && (
                          <div className="flex items-center gap-2">
                            <span>{item.readingTime} دقیقه</span>
                            <Timer className="stroke-dark-gray size-5" />
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
          {/* MAIN VIDEO */}
          <div className="relative aspect-video bg-black overflow-hidden">
            {/* THUMBNAIL (قبل از play) */}
            {!hasPlayed && active.image && (
              <Image
                src={active.image}
                alt={"video poster " + active.title}
                fill
                className="object-cover"
                loading="lazy"
                sizes="(max-width: 768px) 90vw, 40vw"
                quality={50}
                unoptimized={true}
              />
            )}

            {/* VIDEO (فقط بعد از play) */}
            {hasPlayed && (
              <video
                ref={videoRef}
                src={active.video}
                className="absolute inset-0 w-full h-full object-cover"
                controls
                playsInline
                preload="none"
                onEnded={() => setHasPlayed(false)}
              />
            )}

            {/* PLAY BUTTON */}
            {!hasPlayed && (
              <button
                type="button"
                onClick={() => setHasPlayed(true)}
                className="absolute inset-0 z-10 flex items-center justify-center bg-transparent"
                aria-label="play video"
              >
                <div className="rounded-full text-center flex items-center justify-center aspect-square hover:scale-110 transition">
                  <svg width="87" height="87" viewBox="0 0 87 87" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <rect width="86.7799" height="86.7799" rx="43.39" fill="#1A1A18" fillOpacity="0.2" />
                    <path d="M62 37.3038C66 39.6132 66 45.3868 62 47.6962L37.25 61.9856C33.25 64.295 28.25 61.4082 28.25 56.7894L28.25 28.2106C28.25 23.5918 33.25 20.705 37.25 23.0144L62 37.3038Z" fill="white" />
                  </svg>
                </div>
              </button>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}