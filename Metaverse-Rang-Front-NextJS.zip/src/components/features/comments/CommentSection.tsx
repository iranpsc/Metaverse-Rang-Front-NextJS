"use client";

import { useState } from "react";
import { checkData } from "@/components/utils/targetDataName";
import CommentList from "./CommentList";
import SyncLoader from "react-spinners/SyncLoader";
import { useTheme } from "next-themes";
import axios from "axios";
import { findByUniqueId } from "@/components/utils/findByUniqueId";

const CommentSection = ({
  mainData,
  dataCommentsVideo,
  setRefreshComment,
  params,
}: any) => {
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState<boolean>(false);
  const { theme } = useTheme();

  const comments = dataCommentsVideo?.data || [];

  const loadMore = async () => {
    setLoading(true);
    const nextPage = page + 1;

    try {
      await axios.get(
        `${process.env.NEXT_PUBLIC_API_BASE_URL}/api/tutorials?page=${nextPage}`
      );

      // const newVideosData = resVideos.data.data;
      // TODO: append newVideosData to state if needed

    } catch (error) {
      console.error("Load more comments error:", error);
    } finally {
      setLoading(false);
      setPage(nextPage);
    }
  };

  return (
    <div className="w-full mt-10 pt-5 bg-white dark:bg-gray-1 rounded-[20px] min-h-[220px]">
      <p className="w-full text-start px-6 text-singleVideo-gray dark:text-white font-azarMehr font-bold text-2xl xl:text-3xl pb-5">
        {checkData(findByUniqueId(mainData, 457))}
      </p>

      <div className="light-scrollbar dark:dark-scrollbar w-full px-5 xl:max-h-[730px] lg:max-h-[730px] md:h-full sm:h-full xs:h-full xl:overflow-y-scroll lg:overflow-y-scroll overflow-x-clip flex flex-col justify-start items-center gap-10">
        {comments.length > 0 ? (
          <CommentList
            DataItem={dataCommentsVideo}
            mainData={mainData}
            setRefreshComment={setRefreshComment}
            params={params}
          />
        ) : (
          <p className="text-black dark:text-white mt-10">
            {params.lang.toLowerCase() === "fa"
              ? "دیدگاهی وجود ندارد."
              : "No review"}
          </p>
        )}

        {/* VIEW ALL BTN */}
        {comments.length > 5 && (
          <button
            className="text-center rounded-full mb-10 flex items-center justify-center mt-10 py-5 px-10 shadow-xs hover:shadow-md dark:bg-gray-1  text-primary  font-azarMehr font-semibold hover:opacity-90"
            onClick={loadMore}
          >
            {!loading
              ? findByUniqueId(mainData, 171)
              : <SyncLoader color={theme === "dark" ? "#9100D9" : "#0000FF"} size={10} />}
          </button>
        )}
      </div>
    </div>
  );
};

export default CommentSection;
