"use client";
// import { targetData } from "@/components/utils/targetDataName";
// import { Development, Income, Orders, Update } from "@/components/svgs";
import React, { useState, useEffect, useRef } from "react";
import { findByUniqueId } from "@/components/utils/findByUniqueId";
import {
  LevelIncome,
  LevelOrders,
  LevelDevelopment,
  LevelUpdate,
} from "@/components/svgs/SvgLevels";

export const Features = ({ levelsTranslatePage, mainData }: any) => {
  const [inView, setInView] = useState(false);
  // *HINT* useRef WON'T trigger re-render unlike useState.
  const featuresRef = useRef<HTMLDivElement | null>(null);

  // IntersectionObserver to load iframe when it's in view
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        const entry = entries[0];
        if (entry.isIntersecting) {
          setInView(true); // Trigger iframe load when in view
        }
      },
      {
        rootMargin: "0px",
        threshold: 0.1, // Trigger when 10% of the iframe is in view
      }
    );

    if (featuresRef.current) {
      observer.observe(featuresRef.current); // Observe the iframe container
    }

    return () => {
      if (featuresRef.current) {
        observer.unobserve(featuresRef.current); // Cleanup observer
      }
    };
  }, []);

  // If not in view, render a placeholder (or null to defer rendering entirely)
  if (!inView) {
    return <div ref={featuresRef} style={{ minHeight: "500px" }} />;
  }
  return (
    <div
      ref={featuresRef}
      className="pt-8 gap-y-14 mt-7 lg:mt-0 flex flex-wrap justify-center dark:text-white"
    >
      <div className="flex justify-center  items-end px-3 sm:px-4 2xl:px-6 h-[300px] xl:h-[400px] w-full sm:w-1/2 lg:w-1/3 xl:w-1/4 group">
        <div className="w-[90%] relative rounded-[20px] cursor-cell p-3 pb-[15%] pt-[95px]  h-[260px] 2xl:h-[280px] 2xl flex flex-col justify-center items-center dark:bg-gray-1 bg-white base-shadow-1 hover:shadow-[0_0px_20px_rgba(0,0,0,0.45)] dark:hover:text-title-2shadow-[0_0px_35px_-12px_rgba(145,0,217,0.9)] border-solid border border-transparent hover:border-solid hover:border-primary hover: hover:scale-110 base-transition-1">
          <div className="absolute bottom-[calc(100%-70px)]">
            <div className="w-[140px] h-[140px] flex justify-center items-center bg-gray-1 rounded-full border border-solid border-transparent group-hover:border-primary">
              <LevelIncome className="w-[100px] h-[100px]" />
            </div>
          </div>
          <span className="text-xl xl:text-2xl font-bold py-2">
            {findByUniqueId(mainData, 406)}
          </span>
          <p className="text-center text-base 2xl:text-xl font-normal">
            {findByUniqueId(mainData, 407)}
          </p>
          <div className="bg-gray-2  text-primary hover:border-primary border-transparent border-solid border rounded-lg px-5 py-2 mt-5">
            <span>
               {findByUniqueId(mainData, 1842)}
            </span>
          </div>
        </div>
      </div>

      <div className="flex justify-center items-end px-3 sm:px-4 2xl:px-6 h-[300px] xl:h-[400px] w-full sm:w-1/2 lg:w-1/3 xl:w-1/4 group">
        <div className="w-[90%] relative rounded-[20px] cursor-cell p-3 pb-[15%] pt-[95px] h-[260px] 2xl:h-[280px] 2xl flex flex-col justify-center items-center dark:bg-gray-1 bg-white base-shadow-1 hover:shadow-[0_0px_20px_rgba(0,0,0,0.45)] dark:hover:text-title-2shadow-[0_0px_35px_-12px_rgba(145,0,217,0.9)]  border-solid border border-transparent hover:border-solid hover:border-primary hover: hover:scale-110 base-transition-1">
          <div className="absolute bottom-[calc(100%-70px)]">
            <div className="w-[140px] h-[140px] flex justify-center items-center bg-gray-1 rounded-full border border-solid border-transparent group-hover:border-primary">
              <LevelOrders className="w-[100px] h-[100px]" />
            </div>
          </div>
          <span className="text-xl xl:text-2xl font-bold py-2">
            {findByUniqueId(mainData, 408)}
          </span>
          <p className="text-center text-base 2xl:text-xl font-normal">
            {findByUniqueId(mainData, 409)}
          </p>
           <div className="bg-gray-2  text-primary hover:border-primary border-transparent border-solid border rounded-lg px-5 py-2 mt-5">
            <span>
               {findByUniqueId(mainData, 1843)}
            </span>
          </div>
        </div>
      </div>

      <div className="flex justify-center items-end px-3 sm:px-4 2xl:px-6 h-[300px] xl:h-[400px] w-full sm:w-1/2 lg:w-1/3 xl:w-1/4 group">
        <div className="w-[90%] relative rounded-[20px] cursor-cell p-3 pb-[15%] pt-[95px] h-[260px] 2xl:h-[280px] 2xl flex flex-col justify-center items-center dark:bg-gray-1 bg-white base-shadow-1 hover:shadow-[0_0px_20px_rgba(0,0,0,0.45)] dark:hover:text-title-2shadow-[0_0px_35px_-12px_rgba(145,0,217,0.9)]  border-solid border border-transparent hover:border-solid hover:border-primary hover: hover:scale-110 base-transition-1">
          <div className="absolute bottom-[calc(100%-70px)]">
            <div className="w-[140px] h-[140px] flex justify-center items-center bg-gray-1 rounded-full border border-solid border-transparent group-hover:border-primary">
              <LevelDevelopment className="w-[100px] h-[100px]" />
            </div>
          </div>
          <span className="text-xl xl:text-2xl font-bold py-2">
            {findByUniqueId(mainData, 502)}
          </span>
          <p className="text-center text-base 2xl:text-xl font-normal">
            {findByUniqueId(mainData, 410)}
          </p>
           <div className="bg-gray-2  text-primary hover:border-primary border-transparent border-solid border rounded-lg px-5 py-2 mt-5">
            <span>
               {findByUniqueId(mainData, 1844)}
            </span>
          </div>
        </div>
      </div>

      <div className="flex justify-center items-end px-3 sm:px-4 2xl:px-6 h-[300px] xl:h-[400px] w-full sm:w-1/2 lg:w-1/3 xl:w-1/4 group">
        <div className="w-[90%] relative rounded-[20px] cursor-cell p-3 pb-[15%] pt-[95px] h-[260px] 2xl:h-[280px] 2xl flex flex-col justify-center items-center dark:bg-gray-1 bg-white base-shadow-1 hover:shadow-[0_0px_20px_rgba(0,0,0,0.45)] dark:hover:text-title-2shadow-[0_0px_35px_-12px_rgba(145,0,217,0.9)]  border-solid border border-transparent hover:border-solid hover:border-primary hover: hover:scale-110 base-transition-1">
          <div className="absolute bottom-[calc(100%-70px)]">
            <div className="w-[140px] h-[140px] flex justify-center items-center bg-gray-1 rounded-full border border-solid border-transparent group-hover:border-primary">
              <LevelUpdate className="w-[100px] h-[100px]" />
            </div>
          </div>
          <span className="text-xl xl:text-2xl font-bold py-2">
            {findByUniqueId(mainData, 411)}
          </span>
          <p className="text-center text-base 2xl:text-xl font-normal">
            {findByUniqueId(mainData, 412)}
          </p>
           <div className="bg-gray-2  text-primary hover:border-primary border-transparent border-solid border rounded-lg px-5 py-2 mt-5">
            <span>
               {findByUniqueId(mainData, 1845)}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};