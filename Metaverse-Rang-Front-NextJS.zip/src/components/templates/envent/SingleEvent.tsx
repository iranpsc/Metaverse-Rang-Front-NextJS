"use client";
import { useState, useEffect } from "react";
import { findByUniqueId } from "@/components/utils/findByUniqueId";
import { switchDigits } from "@/components/utils/DigitSwitch";
import moment from "moment-jalaali";
import { Like, Dislike, View } from "@/components/svgs/SvgEducation";
import LoginButtonModule from "@/components/features/video/LoginButtonModule";
import { MappedEventItem } from "@/utils/mapEvents";
import Image from "next/image";

// تابع برای پارس تاریخ جلالی
function parseJalaliDatetime(jalaliStr: string): Date {
  return moment(jalaliStr, "jYYYY/jMM/jDD HH:mm").toDate();
}

// محاسبه زمان باقی‌مانده
function getTimeRemaining(targetDate: Date) {
  const now = new Date().getTime();
  const diff = targetDate.getTime() - now;

  if (diff <= 0) {
    return { days: 0, hours: 0, minutes: 0, seconds: 0 };
  }

  const totalSeconds = Math.floor(diff / 1000);
  const days = Math.floor(totalSeconds / (3600 * 24));
  const hours = Math.floor((totalSeconds % (3600 * 24)) / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;

  return { days, hours, minutes, seconds };
}

interface SingleEventProps {
  event: MappedEventItem;
  mainData: any;
  params: any;
  token: string | null;
}

const SingleEvent: React.FC<SingleEventProps> = ({
  event,
  mainData,
  params,
  token,
}) => {
  const [likes, setLikes] = useState<number>(event.likes ?? 0);
  const [disLikes, setDisLikes] = useState<number>(event.disLikes ?? 0);
  const [userLiked, setUserLiked] = useState<boolean>(event.userLiked ?? false);
  const [userDisLiked, setUserDisLiked] = useState<boolean>(
    event.userDisLiked ?? false
  );
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [countdowns, setCountdowns] = useState<{
    toStart: { days: number; hours: number; minutes: number; seconds: number };
    toEnd: { days: number; hours: number; minutes: number; seconds: number };
  }>({
    toStart: { days: 0, hours: 0, minutes: 0, seconds: 0 },
    toEnd: { days: 0, hours: 0, minutes: 0, seconds: 0 },
  });

  // همگام‌سازی state با ایونت جدید (مثلاً بعد از ناوبری کلاینتی)
  useEffect(() => {
    setLikes(event.likes ?? 0);
    setDisLikes(event.disLikes ?? 0);
    setUserLiked(event.userLiked ?? false);
    setUserDisLiked(event.userDisLiked ?? false);
  }, [
    event.id,
    event.likes,
    event.disLikes,
    event.userLiked,
    event.userDisLiked,
  ]);

  // گرفتن وضعیت واکنش کاربر (لایک/دیسلایک) از سرور با توکن
  // چون ممکن است ایونت در صفحه‌ی سروری بدون توکن دریافت شده باشد
  useEffect(() => {
    if (!token) return;

    const controller = new AbortController();

    const loadUserInteraction = async () => {
      try {
        const res = await fetch(
          `${process.env.NEXT_PUBLIC_API_BASE_URL}/api/calendar/${event.id}`,
          {
            headers: {
              Accept: "application/json",
              Authorization: `Bearer ${token}`,
            },
            cache: "no-store",
            signal: controller.signal,
          }
        );
        if (!res.ok) return;

        const json = await res.json();
        const data = json?.data ?? json;
        const ui = data?.user_interaction;
        if (!ui) return;

        setUserLiked(ui.has_liked ?? false);
        setUserDisLiked(ui.has_disliked ?? false);
        if (typeof data.likes === "number") setLikes(data.likes);
        if (typeof data.dislikes === "number") setDisLikes(data.dislikes);
      } catch (error: any) {
        if (error?.name !== "AbortError") {
          console.error("خطا در دریافت وضعیت واکنش کاربر:", error);
        }
      }
    };

    loadUserInteraction();
    return () => controller.abort();
  }, [event.id, token]);

  // تنظیم شمارش معکوس
  useEffect(() => {
    const interval = setInterval(() => {
      const startDate = parseJalaliDatetime(event.start);
      const endDate = parseJalaliDatetime(event.end);
      setCountdowns({
        toStart: getTimeRemaining(startDate),
        toEnd: getTimeRemaining(endDate),
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [event.start, event.end]);

  // مدیریت مشترک لایک (1) و دیسلایک (0)
  const interact = async (liked: 0 | 1) => {
    if (!token) {
      setShowLoginModal(true);
      return;
    }

    if (liked === 1 && userLiked) return;
    if (liked === 0 && userDisLiked) return;

    // نگه‌داشتن مقادیر قبلی برای برگرداندن در صورت خطا
    const prev = { likes, disLikes, userLiked, userDisLiked };

    if (liked === 1) {
      setLikes((n) => n + 1);
      if (userDisLiked) setDisLikes((n) => Math.max(n - 1, 0));
      setUserLiked(true);
      setUserDisLiked(false);
    } else {
      setDisLikes((n) => n + 1);
      if (userLiked) setLikes((n) => Math.max(n - 1, 0));
      setUserDisLiked(true);
      setUserLiked(false);
    }

    try {
      const response = await fetch(
        `${process.env.NEXT_PUBLIC_API_BASE_URL}/api/calendar/events/${event.id}/interact`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({ liked }),
        }
      );

      if (!response.ok) {
        throw new Error(`status ${response.status}`);
      }
    } catch (error) {
      console.error("خطا در ثبت واکنش:", error);
      setLikes(prev.likes);
      setDisLikes(prev.disLikes);
      setUserLiked(prev.userLiked);
      setUserDisLiked(prev.userDisLiked);
    }
  };

  const sendLike = () => interact(1);
  const disLike = () => interact(0);

  const { toEnd } = countdowns;
  const isEnded =
    toEnd.days === 0 &&
    toEnd.hours === 0 &&
    toEnd.minutes === 0 &&
    toEnd.seconds === 0;

  return (
    <>
      <div className="items flex flex-col justify-center gap-3 items-center w-full">
        {/* تصویر ایونت */}
        <div className="mt-4 w-[97%] flex justify-center lg:w-[95%] mx-auto rounded-[20px] overflow-hidden shadow-lg lg:mt-6">
          <Image
            className="w-full h-auto"
            src={
              event.image === "image" || !event.image
                ? "/firstpage/frame.jpg"
                : event.image
            }
            alt={event.title}
            width={960}
            height={540}
            sizes="(max-width: 1024px) 97vw, 60vw"
            priority
            unoptimized
          />
        </div>

        {/* عنوان و لایک/دیسلایک */}
        <div className="flex flex-col w-[97%] lg:w-[95%] gap-3 sm:gap-0 items-center sm:flex-row-reverse sm:justify-between">
          <div className="w-[96%] flex justify-between text-base font-normal font-[Vazir] sm:w-[350px] sm:ml-2 sm:self-center">
            {/* لایک */}
            <button
              type="button"
              onClick={sendLike}
              aria-label="like"
              aria-pressed={userLiked}
              className="flex items-center gap-1 cursor-pointer bg-transparent"
            >
              <Like
                width="20"
                height="24"
                className={`size-[15px] md:size-[18px] transition-all duration-200 ${
                  userLiked
                    ? "fill-primary stroke-primary dark:fill-[#FFD700] dark:stroke-[#FFD700] scale-110"
                    : "fill-none stroke-black dark:stroke-white"
                }`}
              />
              <span className="like-count mt-[2px]">
                {switchDigits(likes, params.lang)}
              </span>
            </button>

            {/* دیسلایک */}
            <button
              type="button"
              onClick={disLike}
              aria-label="dislike"
              aria-pressed={userDisLiked}
              className="flex items-center gap-1 cursor-pointer bg-transparent"
            >
              <Dislike
                width="20"
                height="24"
                className={`size-[15px] md:size-[18px] transition-all duration-200 ${
                  userDisLiked
                    ? "fill-red-500 stroke-red-500 dark:fill-red-400 dark:stroke-red-400 scale-110"
                    : "fill-none stroke-black dark:stroke-white"
                }`}
              />
              <span className="dislike-count">
                {switchDigits(disLikes, params.lang)}
              </span>
            </button>

            {/* بازدید */}
            <div className="flex items-center  gap-1 stroke-black dark:stroke-white">
              <View className="size-[15px] md:size-[18px]" />
              <span>{switchDigits(event.views, params.lang)}</span>
            </div>
          </div>
          <div className="flex items-center justify-between w-full font-[Rokh] my-2 sm:w-[60%] ">
            <div className="flex items-center h-full w-full">
              <div
                style={{ backgroundColor: event.color }}
                className="h-7 xl:h-9 2xl:h-10 rounded-lg aspect-square"
              ></div>
              <span className="mx-2  text-base font-bold lg:text-xl xl:text-2xl 2xl:text-3xl">
                {event.title}
              </span>
            </div>
          </div>
        </div>

        {/* توضیحات ایونت */}
        <div className="text-base lg:w-[95%] wrap-break-word whitespace-normal text-[#868B90] dark:text-[#C4C4C4] mb-4 text-justify leading-6 w-[97%] font-normal font-[Vazir] 2xl:text-xl 2xl:leading-8">
          <div
            dangerouslySetInnerHTML={{
              __html: event.desc, // همیشه متن کامل
            }}
          />
        </div>

        {/* شمارش معکوس */}
        <div
          className="px-4 mb-2 w-[97%] lg:w-[95%] lg:px-7 font-[AzarMehrFD] 
          bg-linear-to-r from-[#CFCFCFE5] to-[#D8D8D800]
          dark:bg-linear-to-r dark:from-[#ffffff09] dark:to-[#00000000]  text-primary rounded-xl lg:rounded-[32px] border border-solid dark:border-[#ffffff25] border-[#CFCFCFE5] shadow-lg p-4 flex flex-col sm:flex-row-reverse sm:h-[250px]"
        >
          <div className="flex flex-col justify-start sm:order-1 sm:content-start sm:w-[30%] sm:min-w-[194px]">
            <h2 className="text-[16px] font-bold lg:px-5 self-center sm:self-start text-black dark:text-white pb-6 sm:mt-4 sm:pb-6 sm:text-start 2xl:text-xl xl:text-lg lg:text-base">
              {findByUniqueId(mainData, 583)} :
            </h2>
            <div
              className="flex justify-center lg:px-5 items-center"
              style={{ direction: "ltr" }}
            >
              <div className="text-center">
                <div className="hale text-2xl font-bold lg:text-3xl xl:text-4xl 3xl:text-5xl">
                  {switchDigits(event.start.split(" ")[0], params.lang)}
                </div>
              </div>
            </div>
          </div>
          <div className="text-center mb-4 sm:w-[30%] sm:min-w-[194px]">
            <h2 className="text-[16px] lg:px-5 font-bold text-black dark:text-white pb-6 sm:pb-6 sm:mt-4 sm:text-start 2xl:text-xl xl:text-lg lg:text-base pt-6 sm:pt-0">
              {findByUniqueId(mainData, 584)}
            </h2>
            {isEnded ? (
              <div
                className="flex justify-center lg:px-5 items-center"
                style={{ direction: "ltr" }}
              >
                <div className="text-center">
                  <div className="hale text-2xl font-bold lg:text-3xl xl:text-4xl 3xl:text-5xl">
                    {switchDigits(event.end.split(" ")[0], params.lang)}
                  </div>
                </div>
              </div>
            ) : (
              <div
                className="flex justify-between items-center"
                style={{ direction: "ltr" }}
              >
                <div className="text-center">
                  <div
                    id="end-days"
                    className="hale text-2xl font-bold lg:text-3xl xl:text-4xl 2xl:text-5xl"
                  >
                    {switchDigits(
                      toEnd.days.toString().padStart(2, "0"),
                      params.lang
                    )}
                  </div>
                  <div className="text-base">{findByUniqueId(mainData, 380)}</div>
                </div>
                <span className="self-start text-[24px] leading-10 font-bold lg:text-3xl xl:text-4xl 2xl:text-5xl">
                  :
                </span>
                <div className="text-center">
                  <div
                    id="end-hours"
                    className="hale text-2xl font-bold w-11 lg:text-3xl xl:text-4xl 2xl:text-5xl"
                  >
                    {switchDigits(
                      toEnd.hours.toString().padStart(2, "0"),
                      params.lang
                    )}
                  </div>
                  <div className="text-base">{findByUniqueId(mainData, 560)}</div>
                </div>
                <span className="self-start text-[24px] leading-10 font-bold lg:text-3xl xl:text-4xl 2xl:text-5xl">
                  :
                </span>
                <div className="text-center">
                  <div
                    id="end-minutes"
                    className="hale text-2xl font-bold w-11 lg:text-3xl xl:text-4xl 2xl:text-5xl"
                  >
                    {switchDigits(
                      toEnd.minutes.toString().padStart(2, "0"),
                      params.lang
                    )}
                  </div>
                  <div className="text-base">{findByUniqueId(mainData, 33)}</div>
                </div>
                <span className="self-start text-[24px] leading-10 font-bold lg:text-3xl xl:text-4xl 2xl:text-5xl">
                  :
                </span>
                <div className="text-center">
                  <div
                    id="end-seconds"
                    className="hale text-2xl font-bold w-11 lg:text-3xl xl:text-4xl 2xl:text-5xl"
                  >
                    {switchDigits(
                      toEnd.seconds.toString().padStart(2, "0"),
                      params.lang
                    )}
                  </div>
                  <div className="text-base">{findByUniqueId(mainData, 778)}</div>
                </div>
              </div>
            )}
          </div>
          <div className="flex text-center sm:justify-center mt-4 sm:w-2/5">
            <a
              href={event.link}
              target="_blank"
              rel="noopener noreferrer"
              className=" bg-primary text-white dark:text-black font-bold py-2 px-4 w-full mb-2 h-11 self-end rounded-[28px] sm:text-lg sm:font-semibold sm:w-[60%] text-center justify-center items-center flex"
            >
              <span>{event.btnName}</span>
            </a>
          </div>
        </div>
        <div className="mt-6 w-full lg:w-[95%] h-[2px] bg-linear-to-r from-transparent via-[#DADADA] to-transparent"></div>
      </div>

      {/* مودال ورود */}
      {showLoginModal && (
        <div className="fixed inset-0 backdrop-blur-sm bg-black/30 flex items-center justify-center z-50 p-5">
          <div className="bg-white dark:bg-dark-background p-6 rounded-lg shadow-lg max-w-sm w-full">
            <h2 className="text-lg md:text-xl font-azarMehr font-bold text-center dark:text-white mb-4">
              {findByUniqueId(mainData, 1459)}
            </h2>
            <div className="flex gap-2 justify-between items-center w-full mt-5">
              <LoginButtonModule params={mainData} />
              <div className="w-1/2 flex justify-center">
                <button
                  className="w-full bg-dark-gray dark:bg-extraGray text-black dark:text-white font-azarMehr py-2 px-2 md:px-4 font-medium text-[15px] rounded-[10px] hover:bg-matn-2-400 active:scale-105 duration-300"
                  onClick={() => setShowLoginModal(false)}
                >
                  {findByUniqueId(mainData, 884)}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default SingleEvent;
