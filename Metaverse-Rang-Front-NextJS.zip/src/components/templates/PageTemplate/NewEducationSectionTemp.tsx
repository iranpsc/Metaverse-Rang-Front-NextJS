"use client";
import ListNewEducationModule from "@/components/features/video/listVideos/ListNewEducationModule";
import { findByUniqueId } from "@/components/utils/findByUniqueId";
import axios from "axios";
import { useTheme } from "next-themes";
import { useEffect, useState } from "react";
import SyncLoader from "react-spinners/SyncLoader";

const NewEducationSectionTemp = ({
  newEducationsVideos,
  mainData,
  params,
}: any) => {
  const [videos, setVideos] = useState<any[]>(newEducationsVideos || []);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState<boolean>(false);
  const { theme } = useTheme();

  useEffect(() => {
    if (newEducationsVideos) {
      // console.log("✅ Initial API data:", newEducationsVideos); // ← اینجا لاگ اولیه
      setVideos(newEducationsVideos);
    }
  }, [newEducationsVideos]);

  const loadMore = async () => {
    setLoading(true);
    const nextPage = page + 1;

    try {
      const resVideos = await axios.get(
        `${process.env.NEXT_PUBLIC_API_BASE_URL}/api/tutorials?page=${nextPage}`
      );

      console.log("📦 Full API response:", resVideos); // ← لاگ کل ریسپانس
      console.log("🎥 API data content:", resVideos.data); // ← فقط دیتا
      console.log("🎬 API video list:", resVideos.data.data); // ← لیست ویدیوها

      const newVideosData = resVideos.data.data || [];
      setVideos((prevVideos) => [...prevVideos, ...newVideosData]);
      setPage(nextPage);
    } catch (error) {
      console.error("❌ Error loading more videos:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col gap-5 px-3 lg:px-5 justify-center items-center relative">
      <h1 className="w-full text-center xs:text-start mt-5 text-[18px] text-singleVideo-gray dark:text-white font-azarMehr font-bold">
        {findByUniqueId(mainData, 190)}
      </h1>
      <hr className="h-[2px] w-[90%] text-singleVideo-backgroundInput dark:text-dark-background mt-5" />

      {videos.length > 0 && (
        <ListNewEducationModule
          videos={videos}
          mainData={mainData}
          params={params}
        />
      )}

      <button
        className="text-center rounded-full mb-10 flex items-center justify-center mt-10 w-[170px] h-[60px] shadow-xs hover:shadow-md dark:bg-gray-1  text-primary  font-azarMehr font-semibold hover:opacity-90"
        onClick={loadMore}
      >
        <div className="flex items-center justify-center w-full h-full">
          {!loading ? (
            <span className="whitespace-nowrap">{findByUniqueId(mainData, 171)}</span>
          ) : (
            <SyncLoader
              color={theme === "dark" ? "#9100D9" : "#0000FF"}
              size={10}
            />
          )}
        </div>
      </button>
    </div>
  );
};

export default NewEducationSectionTemp;
