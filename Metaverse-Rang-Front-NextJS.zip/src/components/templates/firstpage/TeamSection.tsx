"use client";
import React, { useEffect, useRef, useState } from "react";
import { Vector } from "@/components/svgs";
import Image from "next/image";
import Link from "next/link";
import { findByUniqueId } from "@/components/utils/findByUniqueId";
import TeamImg from "@/public/firstpage/teams.jpg";
import { SectionTeamSkeleton } from "@/components/skeleton/SectionTeamSkeleton";

const SectionTeam = ({ mainData, params }: any) => {
  const [isInView, setInView] = useState(false);
  const sectionRef = useRef(null);
  const [linkLoading, setLinkLoading] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        const entry = entries[0];
        if (entry.isIntersecting) {
          setInView(true);
        }
      },
      {
        rootMargin: "0px",
        threshold: 0.01, // Trigger
      }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => {
      if (sectionRef.current) {
        observer.unobserve(sectionRef.current);
      }
    };
  }, []);

  return (
    <div ref={sectionRef} className="w-full">
      {!isInView ? (
        // قبل از رسیدن به viewport: اسکلت هم‌شکل به‌جای فضای خالی قبلی
        <SectionTeamSkeleton />
      ) : (
        <div className="flex flex-column justify-center flex-wrap px-5 lg:px-0 w-full">
          {linkLoading && (
            <div className="fixed top-0 left-0 bottom-0  w-full  h-screen z-70 flex items-center justify-center bg-black/60 backdrop-blur-xs">
              <div className="container flex w-full h-screen items-center justify-center md:ms-[25vw] lg:ms-[17vw] xl:ms-[15vw] 3xl:ms-[16vw]">
                <div className="holder">
                  <div className="box"></div>
                </div>
                <div className="holder">
                  <div className="box"></div>
                </div>
                <div className="holder">
                  <div className="box"></div>
                </div>
              </div>
            </div>
          )}
          <div className="w-full md:w-[50%] lg:w-[35%]">
            <Image
              className="w-full h-full  md:h-auto 3xl:aspect-square object-cover rounded-3xl lg:rounded-xl lg:rounded-[32px] origin-center border-none"
              src={TeamImg}
              alt={"pic " + findByUniqueId(mainData, 256)}
              width={500}
              height={357}
              loading="lazy"
              quality={75}
            />
          </div>

          <div className="w-full lg:w-[65%] flex flex-col justify-between items-start md:pb-3 md:ps-10 gap-1 ">
            <div className="flex flex-col  w-full">
              <h2 className="w-full text-start font-bold text-[20px] md:text-[26px] lg:text-[32px] text-matn-2 dark:text-white mt-5 font-azarMehr">
                {findByUniqueId(mainData, 1457)}
              </h2>
              <Vector className="w-[20%] h-10 stroke-primary dark:stroke-primary" />
            </div>

            <h4 className="w-full text-matn-2 dark:text-white text-[20px] md:text-[24px] lg:text-[28px] text-start pb-2 font-bold ">
              {findByUniqueId(mainData, 490)}
            </h4>

            <p className="w-full  pt-5 md:pt-0 text-justify   text-black dark:text-matn-2 font-azarMehr font-medium text-[14px] md:text-[16px] lg:text-[22px] 3xl:pe-[250px]">
              {findByUniqueId(mainData, 491)}
            </p>

            <div className="w-full flex flex-row justify-start items-center pt-5 md:pt-0">
              <div className="relative flex flex-row justify-start items-start ">
                <Image
                  className="xl:size-[60px] lg:size-[50px] md:size-[70px] sm:size-[50px] xs:size-[44px] rounded-full  z-50"
                  src="/firstpage/person1.webp"
                  alt="hossein ghadiri"
                  width={64}
                  height={64}
                />
                <Image
                  className="xl:size-[60px] lg:size-[50px] md:size-[70px] sm:size-[50px] xs:size-[44px] rounded-full  ms-[-20px] z-40"
                  src="/firstpage/person2.webp"
                  alt="amir madanifar"
                  width={64}
                  height={64}
                />
                <Image
                  className="xl:size-[60px] lg:size-[50px] md:size-[70px] sm:size-[50px] xs:size-[44px] rounded-full ms-[-20px] z-30"
                  src="/firstpage/person3.webp"
                  alt="abbas ajorloo"
                  width={64}
                  height={64}
                />
                <Image
                  className="xl:size-[60px] lg:size-[50px] md:size-[70px] sm:size-[50px] xs:size-[44px] rounded-full  ms-[-20px] z-20"
                  src="/firstpage/pesrion04.jpg"
                  alt="saqeb"
                  width={64}
                  height={64}
                />
                <Image
                  className="xl:size-[60px] lg:size-[50px] md:size-[70px] sm:size-[50px] xs:size-[44px] rounded-full  ms-[-20px] z-10 object-cover"
                  src="/firstpage/person05.webp"
                  alt="Amin DehghanNejad"
                  width={64}
                  height={64}
                />
                <Image
                  className="xl:size-[60px] lg:size-[50px] md:size-[70px] sm:size-[50px] xs:size-[44px] rounded-full  ms-[-20px] z-1 object-cover"
                  src="/firstpage/person6.webp"
                  alt="nazanin heshmati"
                  width={64}
                  height={64}
                />
              </div>

              <p className="ps-2 text-justify text-primary  font-azarMehr font-bold text-[12px] md:text-[18px] lg:text-[24px]">
                + 40 &nbsp;
                {findByUniqueId(mainData, 492)}
              </p>
            </div>
            <Link onClickCapture={() => setLinkLoading(true)} href={`/${params.lang}/about`}>
              <p className="w-fit rounded-[24px] py-3 px-10 mt-5 text-center text-[14px] md:text-[16px] lg:text-[20px] text-white bg-primary  dark:text-black  font-azarMehr font-medium ">
                {findByUniqueId(mainData, 1456)}
              </p>
            </Link>
          </div>
        </div>
      )}
    </div>
  );
};

export default SectionTeam;