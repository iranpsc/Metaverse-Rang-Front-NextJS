import React from "react";
// import SideBar from "@/components/module/sidebar/SideBar";
import Image from "next/image";
import Rafiki from '@/public/rafiki.png';
import RafikiDark from '@/public/rafiki-dark.png';
import SearchComponent from "../Search/SearchComponent";

interface NotFoundPageProps {
  lang: string;
  params: any;
  langData: any;
  langArray: any;
  mainData: any;

}

export default function NotFoundPage({
  lang,
  params,
  langData,
  langArray,
  mainData,

}: NotFoundPageProps) {
  return (
    <div className="flex  w-full" >
      {/* Sidebar فقط وقتی hideSidebar false باشه */}

      {/* Main Content */}
      <section className="w-full pt-7 relative r mt-[60px] lg:mt-0 bg-bg-primary  xl:px-8 lg:px-8 md:px-5 sm:px-5 xs:px-1">


        <div className=" bg-white dark:bg-gray-1 rounded-[20px] flex flex-col lg:flex-row gap-5 p-5 w-full">
          {/* 404 Message */}
          <div className="flex flex-col gap-10 justify-center lg:justify-start items-center lg:items-start text-center lg:text-start w-full lg:w-[60%] p-1 lg:ps-7">
            <h1 className="text-title-2 dark:text-white text-8xl md:text-[120px] 2xl:text-[176px] font-bold mt-5  h-max lg:ps-5">
              404
            </h1>
            <h2 className="text-title-2 dark:text-white text-2xl md:text-3xl ">
              صفحه یافت نشد..!
            </h2>
            <p className="text-[#868B90] text-xl 2xl:text-2xl w-full left-10 leading-[50px]!">
              صفحه‌ای که دنبال آن هستید وجود ندارد. از جستجو کردن کمک بگیرید یا
              به صفحه اصلی بروید.
            </p>
            <div className="w-full 2xl:w-[92%] md:pe-10 mt-[-70px] lg:mt-[-24px]">
              <SearchComponent
                searchLevel="education"
                mainData={mainData}
                params={params}
                fullWidth={true}
              />
            </div>
          </div>
          <div className="lg:mt-[270px] w-full lg:w-[40%] p-2">
            <Image
              src={Rafiki}
              alt="404 pic"
              loading="lazy"
              className="w-full dark:hidden "
            />
            <Image
              src={RafikiDark}
              alt="404 pic"
              loading="lazy"
              className="w-full hidden dark:block"
            />

          </div>
        </div>

       
      </section>
    </div>
  );
}
