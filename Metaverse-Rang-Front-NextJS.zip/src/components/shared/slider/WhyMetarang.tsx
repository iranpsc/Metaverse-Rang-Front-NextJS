'use client';
import { useEffect, useState } from "react";
import { Framer, Hex, DropBox, Wings } from "@/components/svgs/SvgWhitepaper";
import { findByUniqueId } from "@/components/utils/findByUniqueId";
import ClipSection from "@/components/shared/ClipContainer";
import Reveal from "@/components/ui/animations/Reveal";
import Image from "next/image";
interface WhyMetarangProps {
    params: { lang: string };
    mainData: { mainData: string };
}

interface CardData {
    id: number;
    title: string;
    description: string;
    gradient: string;
    icon: React.ReactNode;
}

const svg1 = <Wings className="w-full h-full fill-white" />;
const svg2 = <Hex className="w-full h-full fill-white" />;
const svg3 = <DropBox className="w-full h-full fill-white" />;
const svg4 = <Framer className="w-full h-full fill-white" />;

export default function WhyMetarang({
    params,
    mainData,
}: WhyMetarangProps) {
    const cardsData: CardData[] = [
        {
            id: 1,
            title: findByUniqueId(mainData, 1660),
            description: findByUniqueId(mainData, 1661),
            gradient: "bg-[#3D8BFF] dark:bg-[#19005E] text-[#3D8BFF] dark:text-[#19005E]",
            icon: svg1,
        },
        {
            id: 2,
            title: findByUniqueId(mainData, 1662),
            description: findByUniqueId(mainData, 1663),
            gradient: "bg-[#FF24A8] dark:bg-[#FE0099] text-[#FF24A8] dark:text-[#FE0099]",
            icon: svg2,
        },
        {
            id: 3,
            title: findByUniqueId(mainData, 1664),
            description: findByUniqueId(mainData, 1665),
            gradient: "bg-[#8E02F7] dark:bg-[#9100D9] text-[#8E02F7] dark:text-[#9100D9]",
            icon: svg3,
        },
        {
            id: 4,
            title: findByUniqueId(mainData, 1666),
            description: findByUniqueId(mainData, 1667),
            gradient: "bg-[#01FFE5] dark:bg-[#00CEB9] text-[#01FFE5] dark:text-[#00CEB9]",
            icon: svg4,
        },
    ];
    const [isMobile, setIsMobile] = useState(false);

    useEffect(() => {
        const media = window.matchMedia("(max-width: 1023px)");

        const update = () => setIsMobile(media.matches);

        update();

        media.addEventListener("change", update);

        return () => media.removeEventListener("change", update);
    }, []);

    return (
        <div className="relative ">

            <div className="relative ">
                {/* Card 0 */}
                <div
                    className="sticky h-[39lvh]"
                    style={{
  top: `${isMobile ? 70 : 80}px`,
}}
                >
                    <div
                        className="
            absolute
            left-0
            right-0
            bottom-0
            w-full
            h-lvh
            lg:h-[104lvh]
            xl:h-[112lvh]
            3xl:h-[95lvh]
            overflow-hidden
            flex
            
            
        "
                        style={{
                            top: 0,
                            zIndex: 1,
                        }}
                    >

                        <ClipSection
                            radius={isMobile ? 12 : 32}
                            cornerSize={isMobile ? 80 : 120}
                            cornerRadius={isMobile ? 12 : 16}
                            borderClassName="text-white dark:text-neutral-800"
                            borderWidth={1}
                            corner={params.lang == "fa" ? "tl" : "tr"}
                            className="text-white  dark:text-gray-1  rounded-xl lg:rounded-[32px]  items-center justify-center  lg:p-10 w-full "
                        >
                            <div className=" h-full items-center  px-5 pt-5 lg:pt-0  lg:px-10">
                                <div className="text-5xl md:text-7xl lg:text-9xl uppercase tracking-[.2em] text-black dark:text-white">
                                    <Reveal
                                        className="opacity-100!"
                                        direction={params.lang == "fa" ? "left" : "right"}
                                        distance={isMobile ? 160 : 800}
                                        duration={3000}
                                        delay={300}>
                                        {findByUniqueId(mainData, 1659)}
                                    </Reveal>
                                </div>
                                <p className="text-5xl mt-9 md:text-7xl lg:text-9xl uppercase tracking-[.2em] text-black dark:text-white">
                                    {findByUniqueId(mainData, 257)}
                                </p>
                            </div>
                        </ClipSection>
                    </div>
                </div>

                {cardsData.map((card, index) => (

                    <div
                        key={card.id}
                        className="sticky h-[43lvh] mx-5 lg:mx-9"
style={{
  top: `${isMobile ? 70 : 40}px`,
}}
                    >
                        <div
                            className={`
                absolute
                left-0
                right-0
                bottom-0
                w-full
                h-[80lvh]
                lg:h-[55lvh]
                overflow-hidden
                flex
                flex-col-reverse
                lg:flex-row
              `}
                            style={{
                                top: `${(index + 1) * (isMobile ? 48 : 90)}px`,
                                zIndex: index + 2,
                            }}
                        >
                            {/* Left */}

                            <div className={`flex flex-col  p-5 lg:p-10  w-full lg:w-[60%] rounded-xl lg:rounded-[32px] border border-solid border-white dark:border-neutral-800 ${card.gradient}`}>
                                <div className="hidden lg:flex gap-5">
                                    <div className="text-white/50 tex font-semibold tracking-[.15em] text-xl ">
                                        {(index + 1).toString().padStart(2, "0")}
                                    </div>

                                    <div>

                                        <h3 className="text-3xl lg:text-5xl font-bold uppercase text-white leading-tight">
                                            {card.title}
                                        </h3>

                                        <p className="mt-7 max-w-xl text-white/75 leading-8">
                                            {card.description}
                                        </p>

                                    </div>
                                </div>
                                <Image
                                    src="https://s3.metarang.com/metarang/logo/metarang-logo-512.png"
                                    alt="Logo"
                                    width={45}
                                    height={35}
                                    className="size-10 lg:size-auto lg:w-[35px] lg:h-[35px] object-contain mt-auto hidden lg:block ms-10"
                                />
                                <div className=" flex-col justify-center items-center flex lg:hidden">
                                    <div className="w-[220px] lg:w-[320px]">
                                        {card.icon}
                                    </div>
                                </div>


                            </div>
                            <ClipSection
                                radius={32}
                                cornerSize={120}
                                cornerRadius={16}
                                borderClassName="text-white dark:text-neutral-800"
                                borderWidth={1}
                                corner={params.lang == "fa" ? "tl" : "tr"}
                                className={`${card.gradient} bg-transparent!  items-center justify-center p-10 w-full lg:w-[40%] hidden lg:flex`}>

                                <div className="flex flex-col justify-center items-center">
                                    <div className="w-[220px] lg:w-[320px]">
                                        {card.icon}
                                    </div>
                                </div>

                            </ClipSection>
                            <ClipSection
                                radius={12}
                                cornerSize={80}
                                cornerRadius={12}
                                borderClassName="text-white dark:text-neutral-800"
                                borderWidth={1}
                                corner={params.lang == "fa" ? "tl" : "tr"}
                                className={`${card.gradient} bg-transparent! h-full  gap-3 items-start  p-3 w-full flex-col justify-between lg:w-[40%] flex lg:hidden`}>
                                
                                <div className="flex flex-col gap-5 p-3">
                                    <div className="text-white/50 text-sm font-semibold tracking-[.15em] text-xl">
                                        {(index + 1).toString().padStart(2, "0")}
                                    </div>

                                    <div className="h-full ">

                                        <p className="text-xl pe-[50px]  font-bold uppercase text-white leading-tight">
                                            {card.title}
                                        </p>

                                        <p className="mt-7 max-w-xl pe-[30px] text-white/75 leading-5">
                                            {card.description}
                                        </p>

                                    </div>

                                </div>

                                                                                            <Image
                                    src="https://s3.metarang.com/metarang/logo/metarang-logo-512.png"
                                    alt="Logo"
                                    width={25}
                                    height={25}
                                    className="w-[25px] h-[25px] object-contain mt-auto mb-[-65px] ms-2 lg:hidden"
                                />

                            </ClipSection>

                        </div>

                    </div>
                ))}

            </div>

            <div className="h-[60lvh] 2xl:h-[56.5lvh]" />
        </div>
    );
}
