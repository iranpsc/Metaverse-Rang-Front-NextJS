"use client";

import Image from "next/image";
import { useState, useRef, useEffect } from "react";
import { MenuIcon, ArrowMenu } from "@/svgs/index";
import Link from "next/link";
import ThemeMenuModule from "@/components/shared/sidebar/ThemeMenuModule";
import { useCookies } from "react-cookie";
import DropdownLanguageModule from "./list/dropdowns/DropdownLanguageModule";

interface DropdownLanguageModuleProps {
  languagesData: any;
  langArray: any[];
  params: any;
  isClosed: boolean;
  onLanguageChange?: () => void;
}

const ADMIN_FLAG_BASE =
  "https://dev-admin.metarang.com/assets/images/flags/";

const getFlagSrc = (icon: string, lang: string) => {
  if (!icon) return icon;

  if (icon.startsWith(ADMIN_FLAG_BASE)) {
    const filename = icon.slice(ADMIN_FLAG_BASE.length);

    return `/${lang}/api/flag/${encodeURIComponent(filename)}`;
  }

  return icon;
};

function SideBarHeader({
  isClosed,
  toggleSide,
  params,
  langData,
  langArray,
}: any) {
  const lang = params.lang;

  const [cookies] = useCookies(["theme"]);
  const theme = cookies.theme || "dark";

  const [isLangOpen, setIsLangOpen] = useState(false);
  const langRef = useRef<HTMLDivElement>(null);

  // بستن منوی زبان با کلیک بیرون
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        langRef.current &&
        !langRef.current.contains(event.target as Node)
      ) {
        setIsLangOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);

    return () =>
      document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const currentLang =
    langArray.find((l: { code: any }) => l.code === lang) ||
    langArray[0];

  // ترجمه‌ها
  const translations: Record<
    string,
    { title: string; subtitle: string }
  > = {
    fa: {
      title: "متارنگ",
      subtitle: "متاورس رنگ",
    },
    en: {
      title: "Meta RANG",
      subtitle: "Metaverse RANG",
    },
  };

  const t = translations[lang] || translations.fa;

  return (
    <div className="relative w-full z-101!">
      {/* آیکون منو */}
      <div
        className={`${
          isClosed ? "py-2 w-full" : "hidden my-0"
        }`}
      >
        <MenuIcon
          className={`${
            isClosed ? "visible mt-3" : "hidden my-0"
          } stroke-[#2B2B2B] dark:stroke-white cursor-pointer w-full menu-transition`}
          alt="toggle"
          onClick={toggleSide}
        />
      </div>

      {/* لوگو و متن */}
      <div
        
        className={`${
          isClosed
            ? "mt-3"
            : "flex items-center justify-between"
        } relative overflow-hidden`}
      >
        <Link
        href={`/${params.lang}`}
          className={`${
            isClosed
              ? "w-full justify-center"
              : "justify-start"
          } flex items-center gap-3 my-1 pb-1 menu-transition`}
        >
          <Image
            src="https://s3.metarang.com/metarang/logo/metarang-logo-512.png"
            alt="rgb metaverse"
            width={71}
            height={70}
            className={`${
              isClosed ? "ms-2" : "ms-4"
            } w-[45px] h-[45px] menu-transition`}
          />

          <div
            className={`${
              isClosed
                ? "w-0 h-0"
                : "w-full h-full flex flex-col"
            } overflow-hidden`}
          >
            <p className="whitespace-nowrap visible leading-[25px] dark:text-white block font-azarMehr font-bold text-[14px] md:text-[16px] text-black">
              {t.title}
            </p>

            <p className="whitespace-nowrap leading-[25px] visible font-azarMehr font-normal text-matn-2 text-[14px] md:text-[16px]">
              {t.subtitle}
            </p>
          </div>
        </Link>
      </div>

      <div
        className={`
          flex items-center absolute top-1 md:top-px xl:top-1
          rtl:left-[5px] ltr:right-[5px] mx-2 gap-2
          transition-opacity duration-1000
          ${
            isClosed
              ? "opacity-0 pointer-events-none"
              : "opacity-100 delay-300"
          }
        `}
      >
        {/* منوی زبان */}
        <div
          ref={langRef}
          className={`${
            isClosed ? "hidden" : "block"
          } relative hidden lg:block`}
        >
          <div
            onClick={() => setIsLangOpen(!isLangOpen)}
            className="w-[27px] h-[26px] md:w-[23px] md:h-[23px] xl:w-[27px] xl:h-[27px] rounded-full overflow-hidden border border-matn-2-300 flex items-center justify-center cursor-pointer transition-all hover:scale-110"
          >
            <Image
              src={getFlagSrc(currentLang?.icon, lang)}
              alt={currentLang?.native_name || lang}
              width={28}
              height={28}
              className="object-cover w-full h-full rounded-full"
            />
          </div>

          {isLangOpen && (
            <div className="absolute flex flex-col top-full mt-2 ltr:right-0 rtl:left-0 w-36 bg-white dark:bg-gray-2 rounded-lg shadow-xl border border-matn-2-200 dark:border-dark-border p-3 z-101">
              {langArray.map((langItem: { code: any }) => (
                <DropdownLanguageModule
                  key={langItem.code}
                  languagesData={langData}
                  langArray={[langItem]}
                  params={params}
                  isClosed={isClosed}
                />
              ))}
            </div>
          )}
        </div>

        {/* منوی تم */}
        <div className="hidden lg:block w-[-webkit-fill-available]">
          <ThemeMenuModule
            isClosed={isClosed}
            defaultTheme={theme}
            params={params}
          />
        </div>

        {/* Arrow Menu */}
        <div
          className={`${
            isClosed
              ? "invisible opacity-0"
              : "visible opacity-100 menu-transition"
          } h-[30px] w-[30px] cursor-pointer rounded-full flex justify-center items-center`}
          onClick={toggleSide}
        >
          <ArrowMenu
            className="w-[16px] h-[16px] stroke-matn-2 dark:stroke-white ltr:rotate-180 rtl:rotate-0"
          />
        </div>
      </div>

      <hr
        className={`${
          isClosed ? "mx-3 mt-3" : "mx-2"
        } border border-[#00000017] dark:border-[#3F3F3F] my-1`}
      />
    </div>
  );
}

export default SideBarHeader;