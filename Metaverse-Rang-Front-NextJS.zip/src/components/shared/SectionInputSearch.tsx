"use client";

import { CLoseIcon } from "@/components/svgs";
import { Search } from "@/components/svgs/SvgEducation";
import SyncLoader from "react-spinners/SyncLoader";
import { findByUniqueId } from "../utils/findByUniqueId";

interface SectionInputSearchProps {
  SectionName: string;
  searchLevel: string;
  mainData?: any;
  loadingSearch: boolean;
  defaultTheme: string;
  searchTerm: string;
  params:any;
  setSearchTerm: (val: string) => void;
  searchData: any[];
  removeSearch: () => void;
}

export default function SectionInputSearch({
  SectionName,
  searchLevel,
  mainData,
  params,
  loadingSearch,
  defaultTheme,
  searchTerm,
  setSearchTerm,
  searchData,
  removeSearch,
}: SectionInputSearchProps) {
  // -------------------------------
  // تعیین placeholder بر اساس نوع سرچ
  // -------------------------------
  const getPlaceholder = () => {
    if (searchLevel === "citizen") {
      return findByUniqueId(mainData, 594) || "جستجو میان شهروندها...";
    }
    if (searchLevel === "education") {
      return findByUniqueId(mainData, 167) || "جستجو میان آموزش‌ها...";
    }
    if (searchLevel === "articles") {
      return findByUniqueId(mainData, 1515) || "جستجو میان مقالات...";
    }
    if (searchLevel === "rand_id") {
      return findByUniqueId(mainData, 57) || "جستجو میان شناسه ها...";
    }
    return params.lang == 'fa' ? "جستجو..." : "search...";
  };

  return (
    <div
      className={`
        w-full h-[55px] xs:mt-[50px] xs:mb-5 rounded-2xl border border-transparent
        focus-within:border-primary focus-within:
        transition-all duration-300 bg-white dark:bg-gray-1 
        flex flex-row justify-evenly items-center dark:text-white
      `}
    >
      {/* آیکون سرچ */}
      <Search
        className={`${
          SectionName === "education" ? "ms-8" : "ms-3"
        } fill-primary dark:fill-primary`}
      />

      {/* فیلد ورودی */}
      <input
        type="text"
        placeholder={getPlaceholder()}
        className="w-[80%] outline-hidden border-none 
          placeholder-[#868B90] dark:text-white text-[16px] ms-2
          dark:bg-gray-1  dark:pmatn-2"
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
      />

      {/* Loader در حالت در حال جستجو */}
      {loadingSearch && (
        <SyncLoader
          color={defaultTheme === "dark" ? "#9100D9" : "#9100D9"}
          className="me-1"
          size={5}
          speedMultiplier={0.5}
        />
      )}

      {/* دکمه بستن سرچ یا عبارت آموزشی */}
      {searchData && searchData.length >= 1 ? (
        <CLoseIcon
          className="stroke-error cursor-pointer me-3"
          onClick={removeSearch}
        />
      ) : (
        SectionName === "education" && (
          <span className="text-primary dark:text-dark-activeButton me-5 font-azarMehr font-medium">
            {findByUniqueId(mainData, 57) || "جستجو"}
          </span>
        )
      )}
    </div>
  );
}
