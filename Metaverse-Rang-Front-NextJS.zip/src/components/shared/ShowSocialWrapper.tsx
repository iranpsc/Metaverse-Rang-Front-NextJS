"use client";

import { useState } from "react";
import ShredPageArticle from "./ShredpageArticle";
import { findByUniqueId } from "@/components/utils/findByUniqueId";
import { CopyIcon } from "@/components/svgs/SvgCategories";
import { Like, Dislike, Comment } from "@/components/svgs/SvgEducation";

interface ContentStats {
  comments: number;
  likes: number;
  dislikes: number;
}

interface ContentItem {
  stats?: ContentStats;
  slug: string;
  categorySlug?: string ;
}

interface ShowSocialWrapperProps {
  params: any;
  mainData: any;
  content: ContentItem;
  showStats?: boolean;
}

export default function ShowSocialWrapper({
  params,
  mainData,
  content,
  showStats = true,
}: ShowSocialWrapperProps) {
  const [showSocial, setShowSocial] = useState(false);

  return (
    <div className="flex w-full gap-5 items-center justify-between px-[2px]">
      <div
        onClick={() => setShowSocial(!showSocial)}
        className=" bg-primary flex flex-row w-max items-center gap-2 cursor-pointer rounded-[10px] 3xl:py-[3px] 3xl:px-4 lg:py-2 lg:px-2 md:py-2 md:px-4 sm:py-2 sm:px-4 xs:py-1 xs:px-2"
      >
        <span className="font-azarMehr text-matn-1  font-medium 3xl:text-xl3Title xl:text-xlTitle lg:text-lgTitle md:text-mdTitle sm:text-smTitle xs:text-smTitle">
          {findByUniqueId(mainData, 244)}
        </span>

        <CopyIcon className=" fill-matn-1 3xl:w-[20px] 3xl:h-[20px] md:w-[20px] md:h-[20px]" />
      </div>

      {showStats && content.stats && (
        <div className="flex md:hidden items-center text-sm md:text-base w-full">
          <div className="flex justify-end items-center gap-5 w-full text-matn-2 dark:text-[#888888]">
            <span className="flex items-center gap-1">
              <Comment className="stroke-matn-2 dark:stroke-[#888888] size-[16px]" />
              {content.stats.comments}
            </span>

            <span className="flex items-center gap-1">
              <Like className="stroke-matn-2 dark:stroke-[#888888] size-[16px]" />
              {content.stats.likes}
            </span>

            <span className="flex items-center gap-1">
              <Dislike className="stroke-matn-2 dark:stroke-[#888888] size-[16px]" />
              {content.stats.dislikes}
            </span>
          </div>
        </div>
      )}

      {showSocial && (
        <ShredPageArticle
          params={params}
          mainData={mainData}
          setShowSocial={setShowSocial}
          article={content}
        />
      )}
    </div>
  );
}