"use client";

import Link from "next/link";
import Image from "next/image";
import ClipSection from "../ClipContainer";
import { useEffect, useState } from "react";
import type {
  FooterSection,
} from "@/components/utils/buildShellTranslations";

interface FooterProps {
  params: { lang: string };
  footerSections: FooterSection[];
  brandLabel: string;
}

interface FooterLink {
  label: string;
  href: string;
  targetBlank?: boolean;
  disabled?: boolean;
}

export default function Footer2({
  params,
  footerSections,
  brandLabel,
}: FooterProps) {
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const media = window.matchMedia("(max-width: 1023px)");

    const update = () => setIsMobile(media.matches);

    update();

    media.addEventListener("change", update);

    return () => media.removeEventListener("change", update);
  }, []);

  const isRTL = params.lang === "fa";

  const footerLinks: { title: string; links: FooterLink[] }[] =
    footerSections ?? [];

  return (
    <ClipSection
      radius={isMobile ? 12 : 32}
      cornerRadius={16}
      corner={params.lang === "fa" ? "tl" : "tr"}
      cornerSize={isMobile ? 80 : 120}
      className="text-white dark:text-gray-1"
    >
      <footer className="rounded-xl lg:rounded-[32px] mt-10">
        <div className="overflow-hidden">
          <div className="p-5 xl:p-5 2xl:p-9 3xl:p-14 3xl:px-[76px] mt-5">
            <div className="grid gap-10 gap-y-12 md:grid-cols-[80px_repeat(4,1fr)] 2xl:grid-cols-[350px_repeat(4,1fr)]">

              {/* Logo */}
              <div className="flex items-start justify-start lg:px-0 gap-5">

                {/* MetaRang Logo */}
                <Image
                  src="https://s3.metarang.com/metarang/logo/metarang-logo-512.png"
                  alt="logo"
                  width={isMobile ? 50 : 65}
                  height={isMobile ? 50 : 65}
                  className="w-[50px] h-[50px] inline lg:w-[65px] lg:h-[65px]"
                />

                {/* Enamad */}
                <Link
                  href={`/${params.lang}/enamad`}
                  aria-label={
                    params.lang === "fa"
                      ? "نماد اعتماد الکترونیکی"
                      : "Electronic Trust Symbol"
                  }
                  className="flex items-center justify-center w-[50px] h-[50px] lg:w-[65px] lg:h-[65px]"
                >
                  <Image
                    src="/enamad.png"
                    alt={
                      params.lang === "fa"
                        ? "نماد اعتماد الکترونیکی"
                        : "Electronic Trust Symbol"
                    }
                    width={65}
                    height={65}
                    className="w-full h-full object-contain cursor-pointer"
                  />
                </Link>
              </div>

              {/* Links */}
              {footerLinks.map((section) => (
                <div key={section.title}>
                  <p className="mb-5 lg:mt-3 text-xl 3xl:text-2xl font-medium text-[#1B1B1B] dark:text-[#FFFFFF]">
                    {section.title}
                  </p>

                  <ul className="list-none space-y-[9px]">
                    {section.links.map((item) => {
                      const isExternal =
                        item.targetBlank || item.href.startsWith("http");

                      const baseClass =
                        "peer flex items-center dark:text-[#9A9A9A] hover:text-[#8A2BE2] gap-2 font-bold xl:text-base transition";

                      const isDisabled = item.disabled;

                      const linkClass = isDisabled
                        ? "text-[#aaa] pointer-events-none opacity-50"
                        : "text-[#222]";

                      return (
                        <li key={item.href}>
                          {isDisabled ? (
                            <span className={`${baseClass} ${linkClass}`}>
                              {item.label}

                              <span className="text-[#ccc] text-3xl! ms-1 rtl:rotate-180">
                                <svg
                                  width="20"
                                  height="20"
                                  viewBox="0 0 24 24"
                                  fill="none"
                                  aria-hidden="true"
                                >
                                  <path
                                    d="M5 12H19"
                                    stroke="currentColor"
                                    strokeWidth="1.8"
                                    strokeLinecap="round"
                                  />
                                  <path
                                    d="M13 6L19 12L13 18"
                                    stroke="currentColor"
                                    strokeWidth="1.8"
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                  />
                                </svg>
                              </span>
                            </span>
                          ) : (
                            <Link
                              href={item.href}
                              aria-label="footer links"
                              className={`${baseClass} ${linkClass} hover:text-[#8A2BE2]!`}
                              {...(isExternal
                                ? {
                                    target: "_blank",
                                    rel: "noopener noreferrer",
                                  }
                                : {})}
                            >
                              {item.label}

                              <span className="text-[#8A2BE2] flex items-center rtl:rotate-180 ms-1 text-3xl! transition-transform peer-hover:translate-x-1 peer-hover:rtl:translate-x-[-4px]">
                                <svg
                                  width="20"
                                  height="20"
                                  viewBox="0 0 24 24"
                                  fill="none"
                                  aria-hidden="true"
                                >
                                  <path
                                    d="M5 12H19"
                                    stroke="currentColor"
                                    strokeWidth="1.8"
                                    strokeLinecap="round"
                                  />
                                  <path
                                    d="M13 6L19 12L13 18"
                                    stroke="currentColor"
                                    strokeWidth="1.8"
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                  />
                                </svg>
                              </span>
                            </Link>
                          )}
                        </li>
                      );
                    })}
                  </ul>
                </div>
              ))}
            </div>
          </div>

          {/* MARQUEE */}
          <div className="relative mt-10 mb-7 h-[450px] flex items-center overflow-hidden">
            <div className={`marquee ${isRTL ? "rtl" : "ltr"}`}>
              <div className="track">
                <div className="group">
                  <span className="text-neutral-900 dark:text-white text-[180px] lg:text-[400px]">
                    {brandLabel}
                  </span>
                </div>

                <div className="group">
                  <span className="text-neutral-900 dark:text-white text-[180px] lg:text-[400px]">
                    {brandLabel}
                  </span>
                </div>

                <div className="group">
                  <span className="text-neutral-900 dark:text-white text-[180px] lg:text-[400px]">
                    {brandLabel}
                  </span>
                </div>

                <div className="group">
                  <span className="text-neutral-900 dark:text-white text-[180px] lg:text-[400px]">
                    {brandLabel}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Styles */}
        <style jsx>{`
          .marquee {
            overflow: hidden;
            width: 100%;
          }

          .track {
            display: flex;
            width: max-content;
          }

          .ltr .track {
            animation: scroll-ltr 18s linear infinite;
          }

          .rtl .track {
            animation: scroll-rtl 10s linear infinite;
          }

          .group {
            display: flex;
            flex-shrink: 0;
          }

          .group span {
            font-weight: 700;
            white-space: nowrap;
            padding-right: 80px;
          }

          @keyframes scroll-ltr {
            0% {
              transform: translateX(0);
            }

            100% {
              transform: translateX(-50%);
            }
          }

          @keyframes scroll-rtl {
            0% {
              transform: translateX(0);
            }

            100% {
              transform: translateX(50%);
            }
          }
        `}</style>
      </footer>
    </ClipSection>
  );
}